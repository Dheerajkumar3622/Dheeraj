

import { DynamicFareResult, CrowdForecast, ChurnRiskAnalysis, ChatMessage, DeviationProposal } from '../types';

// Updated to fetch from Server API (Source of Truth)
export const calculateDynamicFare = async (distanceKm: number, timestamp: number): Promise<DynamicFareResult> => {
  try {
    const res = await fetch(`/api/pricing/calculate?distance=${distanceKm}&timestamp=${timestamp}`);
    if (!res.ok) throw new Error("Pricing API failed");
    const data = await res.json();
    
    return {
      totalFare: data.totalFare,
      baseFare: data.baseFare,
      surgeAmount: data.totalFare - data.baseFare,
      discountAmount: 0,
      isRushHour: data.surge > 1,
      isHappyHour: data.surge < 1,
      message: data.message
    };
  } catch (e) {
    // Fallback if offline
    console.warn("Using offline fallback pricing");
    return {
      totalFare: 10 + (distanceKm * 6),
      baseFare: 10 + (distanceKm * 6),
      surgeAmount: 0,
      discountAmount: 0,
      isRushHour: false,
      isHappyHour: false,
      message: 'Offline Estimate'
    };
  }
};

// Keep local simulation for UI responsiveness only
export const getCrowdForecast = (timestamp: number): CrowdForecast => {
  const date = new Date(timestamp);
  const hour = date.getHours();
  // Simple heuristic
  const occupancy = hour > 8 && hour < 19 ? 80 : 30; 
  return {
    level: occupancy > 70 ? 'HIGH' : 'LOW',
    occupancyPercent: occupancy,
    label: occupancy > 70 ? 'Busy' : 'Seats Available',
    hour
  };
};

// ... keep other helpers ...
export const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0
  }).format(amount);
};

export const analyzeChurnRisk = (passes: any[]): ChurnRiskAnalysis => { 
    return { riskLevel: 'LOW', churnProbability: 0.1 }; 
};

export const analyzeCrowdImage = async (c: number) => ({ detectedCount: c, expectedCount: c, discrepancy: 0, confidence: 1 });
export const analyzeDriverFatigue = () => ({ isFatigued: false, confidence: 1 });
export const recognizeFace = async () => ({ match: true });
export const processNaturalLanguageQuery = async (q: string): Promise<ChatMessage> => ({ 
    id: '1', 
    text: "I can help.", 
    sender: 'BOT', 
    timestamp: Date.now() 
});
export const calculateLogisticsCost = (t: string, w: number) => (w * 10);
export const checkForRouteDeviations = (location: string): DeviationProposal | null => null;
