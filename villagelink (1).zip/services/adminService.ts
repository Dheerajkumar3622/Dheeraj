
import { User, AdminStats } from '../types';
import { getAuthToken } from './authService';

const API_URL = '/api/admin';

const getHeaders = () => ({
    'Content-Type': 'application/json',
    'Authorization': getAuthToken() || ''
});

export const getAdminStats = async (): Promise<AdminStats | null> => {
    try {
        const res = await fetch(`${API_URL}/stats`, { headers: getHeaders() });
        if (!res.ok) throw new Error('Failed to fetch stats');
        return await res.json();
    } catch (e) {
        console.error(e);
        return null;
    }
};

export const getAllUsers = async (): Promise<User[]> => {
    try {
        const res = await fetch(`${API_URL}/users`, { headers: getHeaders() });
        if (!res.ok) throw new Error('Failed to fetch users');
        return await res.json();
    } catch (e) {
        console.error(e);
        return [];
    }
};

export const verifyDriver = async (userId: string, isVerified: boolean): Promise<boolean> => {
    try {
        const res = await fetch(`${API_URL}/verify-driver`, {
            method: 'POST',
            headers: getHeaders(),
            body: JSON.stringify({ userId, isVerified })
        });
        return res.ok;
    } catch (e) {
        console.error(e);
        return false;
    }
};

export const toggleUserBan = async (userId: string, isBanned: boolean): Promise<boolean> => {
    try {
        const res = await fetch(`${API_URL}/toggle-ban`, {
            method: 'POST',
            headers: getHeaders(),
            body: JSON.stringify({ userId, isBanned })
        });
        return res.ok;
    } catch (e) {
        console.error(e);
        return false;
    }
};
