
import { ROHTAS_NETWORK, STOP_COORDINATES, ALL_LOCATIONS } from '../constants';

// Breadth-First Search (BFS) to find shortest path in unweighted graph (v6.0 Structure)
export const findShortestPath = (startKey: string, endKey: string): string[] | null => {
  // Normalize keys to lowercase to match ROHTAS_NETWORK keys
  const start = startKey.toLowerCase();
  const end = endKey.toLowerCase();

  // Map display names back to keys if necessary (robustness check)
  const resolveKey = (input: string) => {
    // 1. Direct key match
    if (ROHTAS_NETWORK[input]) return input;
    
    // 2. Name match in Network
    const found = Object.keys(ROHTAS_NETWORK).find(k => ROHTAS_NETWORK[k].name.toLowerCase() === input);
    if (found) return found;

    // 3. Fuzzy match from ALL_LOCATIONS to Network Hubs
    // e.g. "Sasaram (M)" -> "sasaram"
    const simpleInput = input.split('(')[0].trim();
    const fuzzy = Object.keys(ROHTAS_NETWORK).find(k => ROHTAS_NETWORK[k].name.toLowerCase().includes(simpleInput));
    return fuzzy || input;
  };

  const sKey = resolveKey(start);
  const eKey = resolveKey(end);

  if (sKey === eKey) return [ROHTAS_NETWORK[sKey]?.name || startKey];
  if (!ROHTAS_NETWORK[sKey] || !ROHTAS_NETWORK[eKey]) return null;

  const queue: string[][] = [[sKey]];
  const visited = new Set<string>([sKey]);

  while (queue.length > 0) {
    const path = queue.shift();
    if (!path) continue;
    
    const nodeKey = path[path.length - 1];

    if (nodeKey === eKey) {
      // Return proper Names for display
      return path.map(k => ROHTAS_NETWORK[k].name);
    }

    const neighbors = ROHTAS_NETWORK[nodeKey]?.connections || [];
    for (const neighbor of neighbors) {
      if (!visited.has(neighbor)) {
        visited.add(neighbor);
        const newPath = [...path, neighbor];
        queue.push(newPath);
      }
    }
  }

  return null; // No path found
};

// Helper to get squared distance (faster than Haversine for sorting)
const getSqDist = (p1: {lat: number, lng: number}, p2: {lat: number, lng: number}) => {
    return Math.pow(p1.lat - p2.lat, 2) + Math.pow(p1.lng - p2.lng, 2);
};

// Helper: Try to find coordinates for a location name
const getCoords = (name: string) => {
    // 1. Try exact match in STOP_COORDINATES
    if (STOP_COORDINATES[name]) return STOP_COORDINATES[name];
    
    // 2. Try partial match in ALL_LOCATIONS
    const found = ALL_LOCATIONS.find(l => l.name.toLowerCase() === name.toLowerCase() || name.toLowerCase().includes(l.name.toLowerCase()));
    if (found) return { lat: found.lat, lng: found.lng };

    return null;
};

// NEW FEATURE: Detailed Path finding with Intermediate Villages
export const findDetailedPath = (startName: string, endName: string): string[] => {
    // 1. Get the skeleton route (Major Hubs from Graph)
    const skeleton = findShortestPath(startName, endName);
    
    // If no graph route, just return start/end (or straight line logic could be added)
    if (!skeleton) return [startName, endName];

    let fullPath: string[] = [];

    // 2. Interpolate villages between each skeleton segment
    for (let i = 0; i < skeleton.length - 1; i++) {
        const A_Name = skeleton[i];
        const B_Name = skeleton[i+1];
        
        fullPath.push(A_Name);

        const A = getCoords(A_Name);
        const B = getCoords(B_Name);

        if (A && B) {
            // Find villages from geospatial data that lie between A and B
            const intermediates = ALL_LOCATIONS.filter(loc => {
                // Skip if it's A or B itself
                if (loc.name === A_Name || loc.name === B_Name) return false;

                // 1. Bounding Box Check (Optimization)
                // Add a larger buffer (~5km) to ensure we catch villages near the road
                const buffer = 0.05; 
                const minLat = Math.min(A.lat, B.lat) - buffer;
                const maxLat = Math.max(A.lat, B.lat) + buffer;
                const minLng = Math.min(A.lng, B.lng) - buffer;
                const maxLng = Math.max(A.lng, B.lng) + buffer;

                if (loc.lat < minLat || loc.lat > maxLat || loc.lng < minLng || loc.lng > maxLng) return false;

                // 2. Distance from Line Segment Check (Vector Projection)
                // Vector AB
                const dx = B.lng - A.lng;
                const dy = B.lat - A.lat;
                const lenSq = dx*dx + dy*dy;
                
                if (lenSq === 0) return false;

                // Vector AP (Point to Start)
                const pdx = loc.lng - A.lng;
                const pdy = loc.lat - A.lat;

                // Project P onto Line AB to find 't' (0 to 1)
                // t = (AP . AB) / |AB|^2
                let t = (pdx * dx + pdy * dy) / lenSq;

                // Restrict to segment (keep away from nodes to avoid clustering)
                if (t <= 0.05 || t >= 0.95) return false; 

                // Find closest point on line C = A + t*AB
                const Cx = A.lng + t * dx;
                const Cy = A.lat + t * dy;
                
                // Squared distance from line
                const distSq = Math.pow(loc.lng - Cx, 2) + Math.pow(loc.lat - Cy, 2);
                
                // Threshold: Relaxed to 0.001 (approx 2-3km corridor width)
                // This ensures approximate village locations still show up on the route
                return distSq < 0.001; 
            });

            // Sort intermediates by distance from A (to maintain route order)
            intermediates.sort((a, b) => getSqDist(a, A) - getSqDist(b, A));

            // Add village names to path
            intermediates.forEach(loc => fullPath.push(loc.name));
        }
    }
    
    // Add final destination
    fullPath.push(skeleton[skeleton.length - 1]);

    // Remove consecutive duplicates
    return fullPath.filter((item, pos, arr) => !pos || item !== arr[pos - 1]);
};

const calculateHaversine = (lat1: number, lng1: number, lat2: number, lng2: number) => {
  const R = 6371; // Earth radius km
  const dLat = (lat2 - lat1) * (Math.PI / 180);
  const dLng = (lng2 - lng1) * (Math.PI / 180);
  const a = 
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * (Math.PI / 180)) * Math.cos(lat2 * (Math.PI / 180)) * 
    Math.sin(dLng / 2) * Math.sin(dLng / 2); 
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)); 
  return R * c; 
};

export const calculatePathDistance = (pathNames: string[]): number => {
  let totalDist = 0;
  for (let i = 0; i < pathNames.length - 1; i++) {
    const from = getCoords(pathNames[i]);
    const to = getCoords(pathNames[i+1]);
    if (from && to) {
      totalDist += calculateHaversine(from.lat, from.lng, to.lat, to.lng);
    }
  }
  return totalDist;
};

// Simulated Demand Score
export const getDemandLevel = (stopName: string): 'LOW' | 'MED' | 'HIGH' => {
  const hash = stopName.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  const val = hash % 10;
  if (val > 7) return 'HIGH';
  if (val > 5) return 'MED';
  return 'LOW';
};
