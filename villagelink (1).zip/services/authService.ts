
import { User, UserRole, AuthResponse, VehicleType } from '../types';

const API_URL = '/api/auth';
const TOKEN_KEY = 'villagelink_token';
const USER_KEY = 'villagelink_user';

export const registerUser = async (name: string, role: UserRole, password: string, email: string, phone: string, capacity?: number, vehicleType?: VehicleType): Promise<AuthResponse> => {
  try {
    const res = await fetch(`${API_URL}/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, role, password, email, phone, vehicleCapacity: capacity, vehicleType })
    });
    const data = await res.json();
    
    if (data.success) {
      localStorage.setItem(TOKEN_KEY, data.token);
      localStorage.setItem(USER_KEY, JSON.stringify(data.user));
      return data;
    } else {
      return { success: false, message: data.error || "Registration failed" };
    }
  } catch (err) {
    return { success: false, message: "Network Error: Unable to reach server" };
  }
};

export const loginUser = async (loginId: string, password: string): Promise<AuthResponse> => {
  try {
    const res = await fetch(`${API_URL}/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ loginId, password })
    });
    const data = await res.json();
    if (data.success) {
      localStorage.setItem(TOKEN_KEY, data.token);
      localStorage.setItem(USER_KEY, JSON.stringify(data.user));
    } else {
      return { success: false, message: data.error };
    }
    return data;
  } catch (err) {
    return { success: false, message: "Network Error" };
  }
};

export const logoutUser = async () => {
  const token = localStorage.getItem(TOKEN_KEY);
  if (token) {
    try {
      await fetch(`${API_URL}/logout`, {
        method: 'POST',
        headers: { 
          'Authorization': token,
          'Content-Type': 'application/json' 
        }
      });
    } catch (e) { console.error(e); }
  }
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USER_KEY);
};

export const requestPasswordReset = async (identifier: string) => {
  try {
    const res = await fetch(`${API_URL}/forgot-password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ identifier })
    });
    return await res.json();
  } catch (err) {
    return { error: "Network Error" };
  }
};

export const resetPassword = async (identifier: string, token: string, newPassword: string) => {
  try {
    const res = await fetch(`${API_URL}/reset-password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ identifier, token, newPassword })
    });
    return await res.json();
  } catch (err) {
    return { error: "Network Error" };
  }
};

export const getCurrentUser = (): User | null => {
  const stored = localStorage.getItem(USER_KEY);
  return stored ? JSON.parse(stored) : null;
};

export const getAuthToken = (): string | null => {
  return localStorage.getItem(TOKEN_KEY);
};
