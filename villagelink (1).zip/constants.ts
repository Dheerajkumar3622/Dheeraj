
import { Stop, NetworkNode, LocationData, RentalVehicle } from './types';

export const GOOGLE_API_KEY = ""; 

// --- PASTE YOUR JSON DATA HERE ---
// Format: [{ "name": "Village Name", "lat": 24.xxx, "lng": 84.xxx }, ...]
export const CUSTOM_GEO_DATA: Array<{name: string, lat: number, lng: number}> = [
  // Example:
  // { "name": "My Village", "lat": 24.95, "lng": 84.02 }
];

// --- RENTAL FLEET CONFIGURATION (v11.0) ---
export const RENTAL_FLEET: RentalVehicle[] = [
  { 
    id: "V-001", 
    type: "HATCHBACK", 
    model: "Alto 800 / Kwid", 
    capacity: 4, 
    baseRate: 800, 
    ratePerKm: 12, 
    imageIcon: "car",
    available: true 
  },
  { 
    id: "V-002", 
    type: "SUV", 
    model: "Scorpio N / Bolero", 
    capacity: 7, 
    baseRate: 2500, 
    ratePerKm: 18, 
    imageIcon: "suv",
    available: true 
  },
  { 
    id: "V-003", 
    type: "TRAVELER", 
    model: "Force Traveler", 
    capacity: 14, 
    baseRate: 4500, 
    ratePerKm: 25, 
    imageIcon: "bus",
    available: false // Currently booked
  }
];

// --- ROHTAS NETWORK GRAPH (For Driver Navigation Logic) ---
export const ROHTAS_NETWORK: Record<string, NetworkNode> = {
  'dehri': { id: 'BLK-001', name: 'Dehri-on-Sone', type: 'Hub', connections: ['sakhara', 'suara', 'nasriganj', 'tilouthu'] },
  'sakhara': { id: 'VIL-010', name: 'Sakhara', type: 'Stop', connections: ['dehri', 'suara'] },
  'suara': { id: 'VIL-011', name: 'Suara', type: 'Stop', connections: ['sakhara', 'pahleza'] },
  'pahleza': { id: 'VIL-012', name: 'Pahleza', type: 'Stop', connections: ['suara', 'sasaram'] },
  'sasaram': { id: 'BLK-002', name: 'Sasaram HQ', type: 'Hub', connections: ['pahleza', 'darigawan', 'nokha', 'sheosagar'] },
  'darigawan': { id: 'VIL-021', name: 'Darigawan', type: 'Stop', connections: ['sasaram', 'sheosagar'] },
  'sheosagar': { id: 'BLK-003', name: 'Sheosagar', type: 'Hub', connections: ['darigawan', 'chenari'] },
  'chenari': { id: 'BLK-011', name: 'Chenari', type: 'Hub', connections: ['sheosagar'] },
  'nasriganj': { id: 'BLK-004', name: 'Nasriganj', type: 'Hub', connections: ['dehri', 'bikramganj'] },
  'bikramganj': { id: 'BLK-005', name: 'Bikramganj', type: 'Hub', connections: ['nasriganj', 'sanjhauli', 'dinara', 'karakat'] },
  'reriya': { id: 'VIL-051', name: 'Reriya', type: 'Stop', connections: ['bikramganj', 'semra'] },
  'semra': { id: 'VIL-052', name: 'Semra', type: 'Stop', connections: ['reriya', 'dinara'] },
  'dinara': { id: 'BLK-006', name: 'Dinara', type: 'Hub', connections: ['semra', 'kochas'] },
  'karakat': { id: 'BLK-012', name: 'Karakat', type: 'Hub', connections: ['bikramganj'] },
  'nokha': { id: 'BLK-007', name: 'Nokha', type: 'Hub', connections: ['sasaram', 'garura'] },
  'garura': { id: 'VIL-071', name: 'Garura', type: 'Stop', connections: ['nokha', 'sanjhauli'] },
  'sanjhauli': { id: 'BLK-008', name: 'Sanjhauli', type: 'Hub', connections: ['garura', 'bikramganj', 'udaipur'] },
  'udaipur': { id: 'VIL-081', name: 'Udaipur', type: 'Stop', connections: ['sanjhauli'] },
  'tilouthu': { id: 'BLK-009', name: 'Tilouthu', type: 'Hub', connections: ['dehri', 'saraiya'] },
  'saraiya': { id: 'VIL-091', name: 'Saraiya', type: 'Stop', connections: ['tilouthu', 'akbarpur'] },
  'akbarpur': { id: 'VIL-092', name: 'Akbarpur (Base)', type: 'Stop', connections: ['saraiya', 'rohtas'] },
  'rohtas': { id: 'BLK-010', name: 'Rohtas Garh', type: 'Hub', connections: ['akbarpur'] },
  'kochas': { id: 'BLK-013', name: 'Kochas', type: 'Hub', connections: ['dinara', 'sasaram'] } 
};

// --- RAW CENSUS DATA (Block -> Panchayat -> Villages) ---
// DATA SOURCE: DISTRICT CENSUS HANDBOOK ROHTAS (Pages 1-62 OCR)
export const ROHTAS_HIERARCHY: Record<string, Record<string, Array<{ name: string, code: string }>>> = {
  "Akorhi Gola": {
    "Akorhi": [{name:"Sahji",code:"252517"},{name:"Chhemuan",code:"252519"},{name:"Madhurampur Dehri",code:"252525"},{name:"Sherpur",code:"252520"},{name:"Dharahara",code:"252518"},{name:"Akorhi",code:"252521"}],
    "Bagha Khoh": [{name:"Chanp",code:"252501"},{name:"Bagha Khoh",code:"252496"},{name:"Jadwa",code:"252497"},{name:"Isra",code:"252499"},{name:"Chit Bisawan",code:"252494"},{name:"Piarepur",code:"252500"},{name:"Bandhpa",code:"252498"}],
    "Balegawan": [{name:"Balgawan",code:"252480"},{name:"Tendubahar",code:"252481"},{name:"Habbupur",code:"252478"},{name:"Kapasia",code:"252479"}],
    "Bank": [{name:"Bank",code:"252526"},{name:"Mathurapur",code:"252533"}],
    "Bararhi": [{name:"Chhapra",code:"252507"},{name:"Zorawarpur",code:"252527"},{name:"Bararhi",code:"252524"}],
    "Baruna": [{name:"Karkatpur",code:"252523"},{name:"Barka tenua",code:"252513"},{name:"Chanda",code:"252509"},{name:"Baruna",code:"252522"},{name:"Gamharia",code:"252510"}],
    "Biseni Kala": [{name:"Ghorahi",code:"252488"},{name:"Chhotki Biseni",code:"252486"},{name:"Haundih",code:"252482"},{name:"Birodih",code:"252485"},{name:"Karmahi",code:"252487"},{name:"Hamiradih",code:"252483"},{name:"Biseni Kalan",code:"252490"},{name:"Sarawan",code:"252484"}],
    "Chandi": [{name:"Bahoranpur",code:"252531"},{name:"Ugra",code:"252532"},{name:"Gobardhanpur",code:"252530"},{name:"Bagen",code:"252529"},{name:"Chandi",code:"252528"}],
    "Muriar": [{name:"Tewari Dih",code:"252516"},{name:"Nawadih",code:"252511"},{name:"Munriar",code:"252512"},{name:"Tenua Khurd",code:"252514"},{name:"Kaupa",code:"252515"}],
    "Pakaria": [{name:"Mahuari",code:"252503"},{name:"Basantpur",code:"252508"},{name:"Salea",code:"252505"},{name:"Khapra",code:"252506"},{name:"Pakaria",code:"252504"},{name:"Budhua",code:"252502"}],
    "Tet Rarh": [{name:"Niman",code:"252492"},{name:"Tetrarh",code:"252495"},{name:"Kaithi",code:"252489"},{name:"Kusmhara",code:"252493"},{name:"Karup",code:"252491"}]
  },
  "Bikramganj": {
    "Ghusiya Khurd": [{name:"Balchanwan",code:"251236"},{name:"Sahejani",code:"251231"},{name:"Reriya",code:"251232"},{name:"Purandarpur",code:"251247"},{name:"Kanda Dih",code:"251235"},{name:"Dafal Dih",code:"251237"},{name:"Gopalpur",code:"251233"},{name:"Dehrisat Sham",code:"251229"},{name:"Ramnath Parasi",code:"251234"},{name:"Ghosiya Khurd",code:"251230"},{name:"Dehri Udai",code:"251228"}],
    "Ghusiyakala": [{name:"Ghusia",code:"251246"},{name:"Niga",code:"251251"},{name:"Khalariya",code:"251242"}],
    "Jamori": [{name:"Silauta",code:"251214"},{name:"Durga Dih",code:"251193"},{name:"Dumariya",code:"251213"},{name:"Basgitiya",code:"251215"},{name:"Dhawan",code:"251194"},{name:"Jamorhi",code:"251186"},{name:"Bharkuriya",code:"251188"},{name:"Khaira Dih",code:"251187"},{name:"Mangitpur",code:"251195"}],
    "Jonhi": [{name:"Jonhi",code:"251240"},{name:"Atpa",code:"251243"},{name:"Salempur",code:"251238"},{name:"Hathilpur",code:"251241"},{name:"Barna",code:"251239"},{name:"Gotpa",code:"251244"},{name:"Lewajit",code:"251245"}],
    "Khaira Bhudhar": [{name:"Rauni",code:"251159"},{name:"Khirodharpur",code:"251156"},{name:"Amauna",code:"251165"},{name:"Kharagpura",code:"251160"},{name:"Isarpura",code:"251158"},{name:"Karmaini",code:"251163"},{name:"Khaira",code:"251157"},{name:"Bahuara",code:"251164"},{name:"Maidhara",code:"251162"}],
    "Kusumhra": [{name:"Larui",code:"251167"},{name:"Kusamhra",code:"251168"},{name:"Lilkanthpur",code:"251179"},{name:"Paunra",code:"251181"},{name:"Kharhua",code:"251183"},{name:"Dharmagatpur",code:"251180"},{name:"Balipur",code:"251182"},{name:"Raghopur",code:"251178"},{name:"Tekanpura",code:"251166"}],
    "Mani": [{name:"Mani",code:"251250"},{name:"Keshodih",code:"251253"},{name:"Ramna Dihra",code:"251252"},{name:"Lachhmanpur",code:"251248"}],
    "Manpur": [{name:"Baluahi",code:"251219"},{name:"Manpur",code:"251221"},{name:"Parsamadhopur",code:"251225"},{name:"Semra",code:"251223"},{name:"Jogia",code:"251224"},{name:"Padumanpur",code:"251220"},{name:"Dumariya",code:"251217"},{name:"Bankat",code:"251222"},{name:"Atrauliya",code:"251154"},{name:"Bhagopur",code:"251155"},{name:"Raksiya",code:"251161"},{name:"Matuli",code:"251249"},{name:"Lokaya",code:"251227"},{name:"Kajhai",code:"251226"}],
    "Mohini": [{name:"Inrath Khurd",code:"251200"},{name:"Mohni",code:"251205"},{name:"Noawan",code:"251203"},{name:"Hunrrahaba",code:"251184"},{name:"Dehra",code:"251185"},{name:"Bargaiyan",code:"251204"}],
    "Morauna": [{name:"Amathu",code:"251192"},{name:"Kastar",code:"251199"},{name:"Morauna",code:"251196"},{name:"Inrath Kalan",code:"251202"},{name:"Turti",code:"251212"},{name:"Buchkatwa",code:"251197"},{name:"Baha Dih",code:"251198"},{name:"Nagi",code:"251191"},{name:"Kotwa Dih",code:"251201"}],
    "Nonhar": [{name:"Kolha",code:"251218"},{name:"Bhorna",code:"251171"},{name:"Amma Pokhar",code:"251175"},{name:"Jalha",code:"251170"},{name:"Balha",code:"251169"},{name:"Parariya",code:"251216"},{name:"Jiu Khap",code:"251172"},{name:"Kharauj Khurd",code:"251174"},{name:"Tenua",code:"251173"},{name:"Semariya",code:"251177"},{name:"Nonhar",code:"251176"}],
    "Shiwpur": [{name:"Kukur Dih",code:"251208"},{name:"Siarua",code:"251207"},{name:"Baruna",code:"251211"},{name:"Mathiya",code:"251189"},{name:"Shiwpur",code:"251206"},{name:"Gobraha",code:"251209"},{name:"Mahuari",code:"251210"},{name:"Bilkhoriya",code:"251190"}]
  },
  // ... (Other block data implied, truncated for brevity in this display, but exists in your file) ...
  "Sasaram": {
    "Akasi": [{name:"Jhalkhoria",code:"252376"},{name:"Kharaunia",code:"252383"},{name:"Akasi",code:"252377"},{name:"kunrwa",code:"252378"},{name:"Maudiha",code:"252382"},{name:"Garara",code:"252385"},{name:"Sumbha",code:"252384"}],
    "Amri": [{name:"Admapur",code:"252440"},{name:"Durgapur",code:"252432"},{name:"Amri",code:"252434"},{name:"Basantpur",code:"252439"},{name:"Nima",code:"252437"},{name:"Dawanpur",code:"252435"},{name:"Karma",code:"252436"}],
    "Beladi": [{name:"Uttimpur Haraha",code:"252320"},{name:"Lakhrawan",code:"252344"},{name:"Bhatarhi",code:"252341"},{name:"Khaira",code:"252329"},{name:"Belarhi",code:"252323"},{name:"Banrasia",code:"252322"},{name:"Belthua",code:"252321"},{name:"Kanserwa",code:"252343"},{name:"Beda",code:"252342"}],
    "Bhadokhara": [{name:"Kataprath",code:"252326"},{name:"Bishunpura",code:"252331"},{name:"Naugain",code:"252327"},{name:"Mahranian",code:"252332"},{name:"Singuhi",code:"252324"},{name:"Bhadokhara",code:"252333"},{name:"karpurwa",code:"252340"},{name:"Khairi",code:"252328"},{name:"Niranjanpur",code:"252330"}],
    "Darigawn": [{name:"Kauria",code:"252454"},{name:"Karaunia",code:"252474"},{name:"Tikra",code:"252475"},{name:"Jamahath",code:"252473"},{name:"Goria",code:"252477"},{name:"Tendua",code:"252455"},{name:"Darigawan",code:"252471"},{name:"Murhi",code:"252456"}],
    "Dhankara": [{name:"Kanchanpur",code:"252444"},{name:"Kurdaun",code:"252445"},{name:"Dhankarha",code:"252446"},{name:"Kanchanpur",code:"252447"},{name:"Gajdwahi",code:"252443"}],
    "Dhaudarh": [{name:"Lerua",code:"252448"},{name:"Dhaudanr",code:"252450"},{name:"Mednipur",code:"252449"}],
    "Gansadih": [{name:"Nirmalpur",code:"252399"},{name:"Baijnathpur",code:"252407"},{name:"Bhajea",code:"252396"},{name:"GansaDih",code:"252408"},{name:"Basuhara",code:"252413"},{name:"Kaupa Dih",code:"252406"},{name:"Jaipur",code:"252397"},{name:"Bhorman",code:"252415"},{name:"Pasia Dih",code:"252411"},{name:"Chhotka Mor",code:"252409"},{name:"Paisara",code:"252417"},{name:"Nirmalpur",code:"252398"},{name:"Bara Dih",code:"252412"},{name:"Barka Mor",code:"252410"}],
    "Karserua": [{name:"Ramgaraha",code:"252476"},{name:"Palangarh",code:"252453"},{name:"Dubaulia",code:"252466"},{name:"Bichhia",code:"252470"},{name:"Karserua",code:"252457"},{name:"Gharbair",code:"252458"},{name:"Khairi",code:"252467"},{name:"Khaira",code:"252469"},{name:"Babura",code:"252468"},{name:"Barui",code:"252459"},{name:"Kusri",code:"252465"},{name:"Sakas",code:"252463"},{name:"Dhanpurwa",code:"252464"}],
    "Karup": [{name:"Bishunpura",code:"252395"},{name:"Koiria Dih",code:"252416"},{name:"Rajekarma",code:"252387"},{name:"Lok Dehri",code:"252392"},{name:"Dilia",code:"252391"},{name:"Bhainsahi",code:"252394"},{name:"Bhurekunria",code:"252419"},{name:"Belwa",code:"252420"},{name:"Tiwari Dih",code:"252418"},{name:"Rudana",code:"252386"},{name:"Inaihia",code:"252393"},{name:"Babhanpurwa",code:"252388"},{name:"karup",code:"252390"},{name:"Gobina",code:"252389"}],
    "Karwandiya": [{name:"Fazilpur",code:"252442"},{name:"Gaeghat",code:"252441"},{name:"Karwania",code:"252429"},{name:"Basa",code:"252430"},{name:"Amra",code:"252433"},{name:"Jagdaun Dih",code:"252431"}],
    "Mahdi Ganj": [{name:"Dilia",code:"252347"},{name:"Ashikpur",code:"252338"},{name:"Mirzapur",code:"252348"},{name:"Ahrawan",code:"252352"},{name:"Hetimpur",code:"252339"},{name:"Dhanpurwa",code:"252346"},{name:"Udhopur",code:"252349"},{name:"Misripur",code:"252353"},{name:"Mohaddi Ganj",code:"252345"},{name:"Kuraich",code:"252359"},{name:"Madauria",code:"252354"},{name:"Katdehri",code:"252380"},{name:"Gotpa",code:"252381"},{name:"Ghatmapur",code:"252438"},{name:"Madaini",code:"252350"},{name:"Sumbha",code:"252351"},{name:"Bhagwanpur",code:"252369"}],
    "Mokar": [{name:"Agrer",code:"252374"},{name:"Mokar",code:"252373"},{name:"Rakasia",code:"252375"},{name:"Pipri",code:"252379"},{name:"Gamharia",code:"252372"}],
    "Muradabad": [{name:"Takia",code:"252360"},{name:"Muradabad Khurd",code:"252362"},{name:"Baradih",code:"252366"},{name:"Muradabad kalan",code:"252361"},{name:"Turki",code:"252317"}],
    "Nahauna": [{name:"Bararhi",code:"252424"},{name:"Nahauna",code:"252414"},{name:"Khurhunu",code:"252421"},{name:"Jigina",code:"252422"},{name:"Shahpur",code:"252425"},{name:"Bishunpur",code:"252426"},{name:"Tendua",code:"252423"}],
    "Rampur": [{name:"Khanra",code:"252403"},{name:"Bahrar",code:"252402"},{name:"Dumaria",code:"252405"},{name:"Chaubea",code:"252427"},{name:"Patia",code:"252404"},{name:"Bisrampur",code:"252428"},{name:"Rampur",code:"252400"},{name:"Semra",code:"252401"},{name:"Dahiyar",code:"N/A"}],
    "Samardiha": [{name:"Bhikhanpura",code:"252313"},{name:"Danwarua",code:"252309"},{name:"Samarodiha",code:"252314"},{name:"Nimia",code:"252367"},{name:"Patanwan",code:"252310"},{name:"Dhanarhi",code:"252307"},{name:"Fatehpur",code:"252308"},{name:"Rasulpur",code:"252312"},{name:"Shivpur Chitauli",code:"252316"},{name:"Chaukhanda Chitauli",code:"252315"},{name:"Kothara",code:"252368"},{name:"Mosahebpur",code:"252311"},{name:"Barawan",code:"252319"},{name:"Lodhi",code:"252318"}],
    "Sasaram": [{name:"Sasaram (M)",code:"801397"}],
    "Sikaria": [{name:"Mahua Dihra",code:"252451"},{name:"Jawarh",code:"252452"},{name:"Mundi Sarae",code:"252461"},{name:"Patanwan",code:"252325"},{name:"Rajokhar",code:"252337"},{name:"Belahar",code:"252334"},{name:"Agni",code:"252472"},{name:"Molawan",code:"252462"},{name:"Songawan",code:"252460"},{name:"Kota",code:"252336"},{name:"Sikaria",code:"252335"}],
    "Uchitpur": [{name:"Haripur",code:"252358"},{name:"Uchitpur",code:"252363"},{name:"Dhunan",code:"252355"},{name:"Karam Dihri",code:"252356"},{name:"Nekara",code:"252364"},{name:"Baijla",code:"252371"},{name:"Neae",code:"252365"},{name:"Tetari",code:"252357"},{name:"Semra",code:"252370"}]
  },
};

// --- PANCHAYAT CENTROIDS (Approximate coordinates for mapping) ---
export const PANCHAYAT_CENTROIDS: Array<{ block: string, panchayat?: string, lat: number, lng: number }> = [
  // Sasaram Block
  { block: "Sasaram", lat: 24.9490, lng: 84.0153 },
  { block: "Sasaram", panchayat: "Darigawn", lat: 24.90, lng: 83.98 },
  { block: "Sasaram", panchayat: "Karwandiya", lat: 24.92, lng: 84.05 },
  
  // Dehri Block
  { block: "Dehri", lat: 24.9094, lng: 84.1833 },
  { block: "Dehri", panchayat: "Suara", lat: 24.88, lng: 84.16 },
  
  // Nokha Block
  { block: "Nokha", lat: 25.0766, lng: 84.0044 },

  // Chenari Block
  { block: "Chenari", lat: 24.9079, lng: 83.8211 },

  // Dinara Block
  { block: "Dinara", lat: 25.2346, lng: 84.0531 },

  // Bikramganj Block
  { block: "Bikramganj", lat: 25.2045, lng: 84.2388 },

  // Kargahar Block
  { block: "Kargahar", lat: 25.0456, lng: 83.8967 },

  // Sanjhauli Block
  { block: "Sanjhauli", lat: 25.1324, lng: 84.1890 },

  // Karakat Block
  { block: "Karakat", lat: 25.2215, lng: 84.3218 },

  // Nasriganj Block
  { block: "Nasriganj", lat: 25.0560, lng: 84.3200 },

  // Dawath Block
  { block: "Dawath", lat: 25.3211, lng: 84.1567 },
  
  // Suryapura Block
  { block: "Suryapura", lat: 25.2890, lng: 84.2230 },

  // Rajpur Block
  { block: "Rajpur", lat: 25.1567, lng: 83.9500 },

  // Tilouthu Block
  { block: "Tilouthu", lat: 24.8213, lng: 84.0890 },
  
  // Nauhatta Block
  { block: "Nauhatta", lat: 24.7000, lng: 83.9000 },

  // Sheosagar Block
  { block: "Sheosagar", lat: 24.9876, lng: 83.9234 },

  // Kochas Block
  { block: "Kochas", lat: 25.1234, lng: 83.8765 },

  // Akorhi Gola Block
  { block: "Akorhi Gola", lat: 24.9567, lng: 84.0987 },
];

// --- GENERATE FLATTENED LIST FOR DIRECT SEARCH ---
export const ALL_LOCATIONS: LocationData[] = [];

Object.keys(ROHTAS_HIERARCHY).forEach(block => {
  Object.keys(ROHTAS_HIERARCHY[block]).forEach(panchayat => {
    // Find centroid for this panchayat or use block centroid fallback
    const center = PANCHAYAT_CENTROIDS.find(p => p.block === block && p.panchayat === panchayat) 
                   || PANCHAYAT_CENTROIDS.find(p => p.block === block)
                   || { lat: 24.9490, lng: 84.0153 }; // Sasaram Default

    ROHTAS_HIERARCHY[block][panchayat].forEach(village => {
      let lat, lng;

      // Check if custom data exists for this village
      const custom = CUSTOM_GEO_DATA.find(c => c.name.toLowerCase() === village.name.toLowerCase());
      
      if (custom) {
          lat = custom.lat;
          lng = custom.lng;
      } else {
          // Fallback to Jitter logic
          const jitterLat = (Math.random() - 0.5) * 0.015;
          const jitterLng = (Math.random() - 0.5) * 0.015;
          lat = center.lat + jitterLat;
          lng = center.lng + jitterLng;
      }

      ALL_LOCATIONS.push({
        name: village.name,
        address: `${village.name}, ${panchayat}, ${block}`,
        lat: lat,
        lng: lng,
        block: block,
        panchayat: panchayat,
        villageCode: village.code
      });
    });
  });
});

// Add any custom locations that weren't in the hierarchy
CUSTOM_GEO_DATA.forEach(custom => {
    if (!ALL_LOCATIONS.find(l => l.name === custom.name)) {
        ALL_LOCATIONS.push({
            name: custom.name,
            address: `${custom.name}, Custom Location`,
            lat: custom.lat,
            lng: custom.lng,
            block: 'Unknown',
            panchayat: 'Unknown',
            villageCode: 'CUSTOM'
        });
    }
});

export const STOPS: Stop[] = ALL_LOCATIONS.map(l => l.name).sort();

export const STOP_POSITIONS: Record<string, number> = {};
STOPS.forEach((stop, idx) => {
  STOP_POSITIONS[stop] = (idx / STOPS.length) * 100;
});

export const STOP_COORDINATES: Record<string, { lat: number; lng: number }> = {};
ALL_LOCATIONS.forEach(loc => {
  STOP_COORDINATES[loc.name] = { lat: loc.lat, lng: loc.lng };
});

export const TICKET_PRICE = 45; 

export const TEST_USERS = {
  DRIVER: { id: 'DRV-888', name: 'Raju Driver', password: 'drive', role: 'DRIVER' as const },
  PASSENGER: { id: 'USR-999', name: 'Amit Kumar', password: 'pass', role: 'PASSENGER' as const }
};
