
import React, { useState, useEffect } from 'react';
import { Ticket, TicketStatus, PaymentMethod, User, LocationData, Pass, SeatConfig, ChurnRiskAnalysis, RentalVehicle, RentalBooking, ParcelBooking, Wallet as WalletType, GeoLocation, CrowdForecast, DynamicFareResult } from '../types';
import { RENTAL_FLEET } from '../constants';
import { generateTicketId, generatePassId, generateRentalId, generateParcelId, saveTicket, savePass, getStoredTickets, getMyPasses, bookRental, bookParcel } from '../services/transportService';
import { calculateDynamicFare, getCrowdForecast, formatCurrency, analyzeChurnRisk, calculateLogisticsCost } from '../services/mlService';
import { getWallet, mintPassNFT, createEscrow, earnGramCoin, spendGramCoin } from '../services/blockchainService';
import { getBehavioralScore, generateDeviceFingerprint, encryptData, signTransaction, isTravelPossible, updateLastLocation } from '../services/securityService';
import { findDetailedPath } from '../services/graphService';
import { isOnline, queueAction } from '../services/offlineService';
import { scanMeshPeers, broadcastToMesh } from '../services/advancedFeatures';
import { Button } from './Button';
import { LiveTracker } from './LiveTracker';
import { LocationSelector } from './LocationSelector';
import { Modal } from './Modal';
import { PaymentGatewayModal } from './PaymentGatewayModal';
import { DigitalTwinSeatMap } from './DigitalTwinSeatMap';
import { ARFinder } from './ARFinder';
import { BottomNav } from './BottomNav';
import { UserProfile } from './UserProfile';
import { Ticket as TicketIcon, Check, Zap, Bus, MapPin, Route, CreditCard, User as UserIcon, Sparkles, Car, Package, Box, ShieldCheck, Gem, Lock, WifiOff, Scan, ArrowLeft, ChevronRight, Search, Truck, Share2, Leaf, Radio, Link } from 'lucide-react';

interface PassengerViewProps {
  user: User;
}

const calculateDistance = (lat1: number, lng1: number, lat2: number, lng2: number) => {
  const R = 6371; 
  const dLat = (lat2 - lat1) * (Math.PI / 180);
  const dLng = (lng2 - lng1) * (Math.PI / 180);
  const a = 
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * (Math.PI / 180)) * Math.cos(lat2 * (Math.PI / 180)) * 
    Math.sin(dLng / 2) * Math.sin(dLng / 2); 
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)); 
  return R * c; 
};

export const PassengerView: React.FC<PassengerViewProps> = ({ user }) => {
  // Navigation State
  const [currentView, setCurrentView] = useState<'DASHBOARD' | 'BOOK_RENTAL' | 'BOOK_PARCEL'>('DASHBOARD');
  const [activeTab, setActiveTab] = useState<'HOME' | 'PASSES' | 'LOGISTICS' | 'PROFILE'>('HOME');
  const [isOfflineMode, setIsOfflineMode] = useState(!isOnline());
  
  // Public Transport State
  const [fromLocation, setFromLocation] = useState<LocationData | null>(null);
  const [toLocation, setToLocation] = useState<LocationData | null>(null);
  const [tripDistance, setTripDistance] = useState<number | null>(null);
  const [calculatedPath, setCalculatedPath] = useState<string[]>([]);
  
  const [activeTickets, setActiveTickets] = useState<Ticket[]>([]);
  const [myPasses, setMyPasses] = useState<Pass[]>([]);
  
  const [passengerCount, setPassengerCount] = useState(1);
  const [showToast, setShowToast] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [isBooking, setIsBooking] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>(PaymentMethod.CASH);
  const [showPaymentGateway, setShowPaymentGateway] = useState(false);

  // Digital Twin & AR State (v14.0)
  const [selectedSeat, setSelectedSeat] = useState<string | null>(null);
  const [showAR, setShowAR] = useState(false);

  // Pass State
  const [isBuyingPass, setIsBuyingPass] = useState(false);
  const [seatConfig, setSeatConfig] = useState<SeatConfig>('SEAT');

  // Logistics State (v11.1)
  const [logisticsWeight, setLogisticsWeight] = useState(5);
  const [logisticsItemType, setLogisticsItemType] = useState('BOX_SMALL');
  const [logisticsPrice, setLogisticsPrice] = useState(0);

  // ML State
  const [churnAnalysis, setChurnAnalysis] = useState<ChurnRiskAnalysis | null>(null);
  const [fareDetails, setFareDetails] = useState<DynamicFareResult | null>(null);
  const [crowdForecast, setCrowdForecast] = useState<CrowdForecast | null>(null);
  const [passPrice, setPassPrice] = useState<number>(0);

  // Rental State (v11.0)
  const [selectedVehicle, setSelectedVehicle] = useState<RentalVehicle | null>(null);
  const [tripType, setTripType] = useState<'ONE_WAY' | 'ROUND_TRIP'>('ONE_WAY');
  const [rentalDate, setRentalDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [rentalPrice, setRentalPrice] = useState<number>(0);

  // Blockchain & Security State (v12.0 + v13.0)
  const [wallet, setWallet] = useState<WalletType | null>(null);
  const [trustScore, setTrustScore] = useState(1.0);

  useEffect(() => {
    // Offline Listener
    window.addEventListener('online', () => setIsOfflineMode(false));
    window.addEventListener('offline', () => setIsOfflineMode(true));

    // Security Check
    const verifyDevice = async () => {
        await generateDeviceFingerprint();
        setTrustScore(getBehavioralScore());
    };
    verifyDevice();

    const fetchTickets = () => {
      const all = getStoredTickets().filter(t => t.userId === user.id);
      setActiveTickets(all.filter(t => ['PENDING', 'BOARDED', 'PAID'].includes(t.status)));
    };
    const fetchPasses = async () => {
       const passes = await getMyPasses(user.id);
       setMyPasses(passes);
       const risk = analyzeChurnRisk(passes);
       if (risk.riskLevel === 'HIGH' && risk.recommendedOffer) {
           setChurnAnalysis(risk);
       }
    };
    const fetchWallet = async () => {
        const w = await getWallet(user.id);
        setWallet(w);
    };

    fetchTickets();
    fetchPasses();
    fetchWallet();
    const interval = setInterval(() => {
        fetchTickets();
        fetchPasses();
        fetchWallet();
        // Update trust score periodically based on new interactions
        setTrustScore(getBehavioralScore());
    }, 5000);
    return () => {
        clearInterval(interval);
        window.removeEventListener('online', () => setIsOfflineMode(false));
        window.removeEventListener('offline', () => setIsOfflineMode(true));
    };
  }, [user.id]);

  useEffect(() => {
    if (currentView === 'BOOK_PARCEL') {
        setLogisticsPrice(calculateLogisticsCost(logisticsItemType, logisticsWeight));
    }

    if (fromLocation && toLocation) {
      const dist = calculateDistance(fromLocation.lat, fromLocation.lng, toLocation.lat, toLocation.lng);
      setTripDistance(dist);
      
      // AUTO-ROUTE GEN: Use new detailed path finder
      const detailedPath = findDetailedPath(fromLocation.name, toLocation.name);
      
      if (detailedPath && detailedPath.length > 0) {
        setCalculatedPath(detailedPath);
      } else {
        setCalculatedPath([fromLocation.name, "Direct Route", toLocation.name]);
      }

      if (currentView === 'DASHBOARD') {
        calculateDynamicFare(dist, Date.now()).then(dynamicFare => {
          setFareDetails(dynamicFare);
          
          let monthly = dynamicFare.baseFare * 20;
          if (seatConfig === 'STANDING') monthly = monthly * 0.80;
          if (churnAnalysis?.recommendedOffer && isBuyingPass) monthly = monthly * (1 - churnAnalysis.recommendedOffer.discountPercent/100);
          setPassPrice(Math.round(monthly));
        });

        const crowd = getCrowdForecast(Date.now());
        setCrowdForecast(crowd);

      } else if (currentView === 'BOOK_RENTAL') {
        if (selectedVehicle) {
             const effectiveDist = tripType === 'ROUND_TRIP' ? dist * 2 : dist;
             const price = selectedVehicle.baseRate + (effectiveDist * selectedVehicle.ratePerKm);
             setRentalPrice(Math.round(price));
        }
      }
    } else {
      setTripDistance(null);
      setFareDetails(null);
      setCrowdForecast(null);
      setPassPrice(0);
      setRentalPrice(0);
      setCalculatedPath([]);
    }
  }, [fromLocation, toLocation, seatConfig, isBuyingPass, churnAnalysis, currentView, selectedVehicle, tripType, logisticsWeight, logisticsItemType]);

  const initiateBook = () => {
    // Relaxed security check for demo purposes and mobile usability
    if (trustScore < 0.2) {
        alert("Security Alert: Unusual traffic detected. Please verify you are human.");
        return;
    }
    
    // Removed strict geo-check for booking initiation to prevent UX blocks
    // We still update the location for background safety monitoring
    if (fromLocation) {
        const currentGeo: GeoLocation = { lat: fromLocation.lat, lng: fromLocation.lng, timestamp: Date.now() };
        updateLastLocation(currentGeo);
    }

    if (!fromLocation || !toLocation) {
      alert("Please select start and end villages.");
      return;
    }
    setShowConfirm(true);
  };

  const handleReviewConfirm = () => {
    if (paymentMethod === PaymentMethod.GRAMCOIN) {
        const totalCost = (fareDetails?.totalFare || 0) * passengerCount;
        if (spendGramCoin(user.id, totalCost, "Bus Ticket")) {
            completeBooking(PaymentMethod.GRAMCOIN, TicketStatus.PAID);
        } else {
            alert("Insufficient GramCoin Balance");
        }
        return;
    }

    if (isOfflineMode && !isBuyingPass && currentView === 'DASHBOARD') {
        const totalFare = (fareDetails?.totalFare || 0) * passengerCount;
        const offlineTicket = {
            userId: user.id,
            from: fromLocation!.name,
            to: toLocation!.name,
            fromDetails: fromLocation!.address,
            toDetails: toLocation!.address,
            status: TicketStatus.PENDING,
            paymentMethod: PaymentMethod.CASH,
            passengerCount,
            totalPrice: totalFare,
            routePath: calculatedPath,
            seatNumber: selectedSeat || undefined
        };
        queueAction({ type: 'BOOK_TICKET', payload: offlineTicket });
        alert("Offline: Ticket queued! Will sync when online.");
        setShowConfirm(false);
        resetToDashboard();
        return;
    }

    if (isBuyingPass || currentView === 'BOOK_RENTAL' || currentView === 'BOOK_PARCEL') {
        setShowConfirm(false);
        setShowPaymentGateway(true);
        return;
    }
    
    if (paymentMethod === PaymentMethod.CASH) {
      completeBooking(PaymentMethod.CASH, TicketStatus.PENDING);
    } else {
      setShowConfirm(false);
      setShowPaymentGateway(true);
    }
  };

  const completeBooking = async (method: PaymentMethod, status: TicketStatus) => {
    setIsBooking(true);
    const signature = await signTransaction({ userId: user.id, amount: rentalPrice || passPrice, type: 'BOOKING' });

    if (currentView === 'BOOK_RENTAL') {
        const contract = createEscrow(user.id, 'VL-SYSTEM', rentalPrice);
        const newRental: RentalBooking = {
            id: generateRentalId(),
            userId: user.id,
            userName: user.name,
            vehicleType: selectedVehicle!.type,
            from: fromLocation!.name,
            to: toLocation!.name,
            tripType: tripType,
            date: rentalDate,
            distanceKm: tripDistance!,
            totalFare: rentalPrice,
            status: 'PENDING',
            escrowContractId: contract.id 
        };
        await bookRental(newRental);
    } 
    else if (currentView === 'BOOK_PARCEL') {
        const encryptedItemType = await encryptData(logisticsItemType); 
        const newParcel: ParcelBooking = {
          id: generateParcelId(),
          userId: user.id,
          from: fromLocation!.name,
          to: toLocation!.name,
          itemType: encryptedItemType,
          weightKg: logisticsWeight,
          price: logisticsPrice,
          status: 'PENDING',
          isEncrypted: true,
          blockchainHash: signature
        };
        await bookParcel(newParcel);
        earnGramCoin(user.id, 2, "Logistics Reward");
    }
    else if (isBuyingPass) {
        const nftData = mintPassNFT(user.id, { from: fromLocation!.name, to: toLocation!.name, expiry: Date.now() + 30*24*60*60*1000 });
        const newPass: Pass = {
            id: generatePassId(),
            userId: user.id,
            userName: user.name,
            from: fromLocation!.name,
            to: toLocation!.name,
            type: 'MONTHLY',
            seatConfig: seatConfig,
            validityDays: 30,
            usedDates: [],
            purchaseDate: Date.now(),
            expiryDate: Date.now() + (30 * 24 * 60 * 60 * 1000),
            price: passPrice,
            status: 'ACTIVE',
            nftMetadata: nftData
        };
        await savePass(newPass);
        setMyPasses(prev => [newPass, ...prev]);
        earnGramCoin(user.id, 50, "Monthly Pass Bonus");
    } else {
        const newTicket: Ticket = {
            id: generateTicketId(),
            userId: user.id,
            from: fromLocation!.name,
            to: toLocation!.name,
            fromDetails: fromLocation!.address,
            toDetails: toLocation!.address,
            status: status,
            paymentMethod: method,
            timestamp: Date.now(),
            passengerCount: passengerCount,
            totalPrice: (fareDetails?.totalFare || 0) * passengerCount,
            routePath: calculatedPath,
            digitalSignature: signature,
            seatNumber: selectedSeat || undefined
        };
        saveTicket(newTicket);
        setActiveTickets(prev => [newTicket, ...prev]);
        earnGramCoin(user.id, 1 * passengerCount, "Trip Reward"); 
    }

    setIsBooking(false);
    setShowConfirm(false);
    setShowPaymentGateway(false);
    setShowToast(true);
    setTimeout(() => {
        setShowToast(false);
        resetToDashboard();
    }, 2500);
  };

  const resetToDashboard = () => {
      setCurrentView('DASHBOARD');
      setActiveTab('HOME');
      setFromLocation(null);
      setToLocation(null);
      setSelectedVehicle(null);
      setIsBuyingPass(false);
  };

  const handleTabChange = (tab: 'HOME' | 'PASSES' | 'LOGISTICS' | 'PROFILE') => {
      setActiveTab(tab);
      // Ensure we clear any specific functional views (Parcel/Rental) when switching tabs
      setCurrentView('DASHBOARD');
      
      // If the user explicitly clicked "LOGISTICS" (Parcel Icon), we might want to show the parcel view,
      // OR we can just show a list of parcels. 
      // Based on the simplified flow requested, let's keep LOGISTICS as the Parcel Booking view for now,
      // but ensure it doesn't overlap with others.
      if (tab === 'LOGISTICS') {
          setCurrentView('BOOK_PARCEL');
      }
  };

  const shareTicketMesh = async (ticket: Ticket) => {
      const peers = await scanMeshPeers();
      if (peers.length > 0) {
          const success = broadcastToMesh(ticket);
          if (success) alert(`Shared with ${peers[0].name} via Mesh`);
      } else {
          alert("No nearby devices found");
      }
  };

  const handleShareTrip = async (ticket: Ticket) => {
      const shareUrl = `${window.location.origin}/track?id=${ticket.id}`;
      const shareData = {
          title: 'VillageLink Live Tracking',
          text: `I am travelling from ${ticket.from} to ${ticket.to}. Track my bus live:`,
          url: shareUrl
      };

      if (navigator.share) {
          try {
              await navigator.share(shareData);
          } catch (err) {
              console.log('Share skipped');
          }
      } else {
          navigator.clipboard.writeText(`${shareData.text} ${shareData.url}`);
          alert("Tracking link copied to clipboard");
      }
  };

  const getRentalIcon = (type: string) => {
    switch (type) {
        case 'car': return <Car size={24} />;
        case 'suv': return <Car size={24} className="scale-110" />;
        case 'bus': return <Bus size={24} />;
        default: return <Car size={24} />;
    }
  };

  return (
    <>
        <div className="max-w-md mx-auto animate-fade-in pb-32 relative min-h-screen font-sans">
        {showAR && <ARFinder onClose={() => setShowAR(false)} targetName={calculatedPath[1] || 'Bus Stop'} />}

        {/* Header Area - Hide when in Profile or Passes to avoid double headers or clutter */}
        {activeTab === 'HOME' && (
            <div className="mb-6 px-2 flex justify-between items-start">
                <div>
                <div className="flex items-center gap-2 mb-1">
                    <span className="text-slate-500 dark:text-slate-400 text-sm font-medium">Namaste,</span>
                    <h2 className="text-xl font-bold dark:text-white">{user.name.split(' ')[0]}</h2>
                </div>
                {isOfflineMode && <div className="bg-slate-200 text-slate-600 px-2 py-0.5 rounded text-[10px] font-bold inline-flex items-center gap-1"><WifiOff size={8} /> OFFLINE MODE</div>}
                </div>
                <div className="bg-white/80 dark:bg-slate-800/80 backdrop-blur px-3 py-1.5 rounded-full border border-slate-200 dark:border-slate-700 flex items-center gap-2 shadow-sm">
                    <Gem size={14} className="text-yellow-500" />
                    <span className="text-xs font-bold dark:text-white">{wallet?.balance || 0}</span>
                </div>
            </div>
        )}

        {/* MAIN DASHBOARD (BUS IS PRIMARY) */}
        {activeTab === 'HOME' && currentView === 'DASHBOARD' && (
            <div className="space-y-6 animate-fade-in">
                {/* Active Ticket Banner */}
                {activeTickets.length > 0 && (
                    <div className="bg-slate-900 rounded-[28px] p-5 text-white shadow-xl relative overflow-hidden">
                        <div className="absolute top-0 right-0 w-32 h-32 bg-brand-500/20 rounded-full blur-2xl -mr-10 -mt-10"></div>
                        <div className="relative z-10 flex justify-between items-start mb-4">
                            <div>
                                <p className="text-[10px] font-bold opacity-60 uppercase tracking-wider mb-1">Current Trip</p>
                                <h3 className="text-lg font-bold">{activeTickets[0].from} <span className="opacity-50 mx-1">to</span> {activeTickets[0].to}</h3>
                            </div>
                            <div className="flex flex-col items-end gap-1">
                                <span className="bg-emerald-500 text-white text-[10px] font-bold px-2 py-1 rounded-full">{activeTickets[0].status}</span>
                                <div className="flex gap-2 mt-1">
                                    <button onClick={() => handleShareTrip(activeTickets[0])} className="text-[10px] flex items-center gap-1 bg-white/20 hover:bg-white/30 px-2 py-1 rounded transition-colors backdrop-blur-md">
                                        <Link size={10} /> Share Link
                                    </button>
                                    <button onClick={() => shareTicketMesh(activeTickets[0])} className="text-[10px] flex items-center gap-1 opacity-70 hover:opacity-100 px-1">
                                        <Share2 size={10} /> Mesh
                                    </button>
                                </div>
                            </div>
                        </div>
                        
                        {/* TRACKING MODULE */}
                        <LiveTracker desiredPath={activeTickets[0].routePath} />

                        <div className="relative z-10 bg-white/10 rounded-xl p-3 flex justify-between items-center backdrop-blur-sm mt-4">
                            <span className="text-xs font-mono">{activeTickets[0].id}</span>
                            <button onClick={() => setShowAR(true)} className="flex items-center gap-1 text-xs font-bold text-brand-300"><Scan size={14} /> AR View</button>
                        </div>
                    </div>
                )}

                {/* PRIMARY FEATURE: BUS BOOKING INTERFACE */}
                <div className="glass-panel rounded-[32px] p-6 shadow-2xl relative border border-white/50 dark:border-white/5">
                    <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-2 text-brand-600 dark:text-brand-400">
                            <Bus size={20} fill="currentColor" className="opacity-20" />
                            <h2 className="text-lg font-bold dark:text-white">Plan Your Journey</h2>
                        </div>
                        <div className="bg-slate-100 dark:bg-slate-800 p-1 rounded-full flex text-[10px] font-bold">
                            <button onClick={() => setIsBuyingPass(false)} className={`px-3 py-1 rounded-full transition-all ${!isBuyingPass ? 'bg-white shadow text-brand-600' : 'text-slate-400'}`}>Ticket</button>
                            <button onClick={() => setIsBuyingPass(true)} className={`px-3 py-1 rounded-full transition-all ${isBuyingPass ? 'bg-white shadow text-brand-600' : 'text-slate-400'}`}>Pass</button>
                        </div>
                    </div>

                    <div className="space-y-4 mb-6 relative z-30">
                        <LocationSelector label="From" onSelect={setFromLocation} icon={<MapPin size={18} className="text-brand-500" />} />
                        <LocationSelector label="To" onSelect={setToLocation} icon={<MapPin size={18} className="text-neon-magenta" />} />
                    </div>

                    {fromLocation && toLocation && fareDetails ? (
                        <div className="space-y-4 animate-fade-in">
                            {!isBuyingPass && <DigitalTwinSeatMap onSelectSeat={setSelectedSeat} selectedSeat={selectedSeat} />}
                            
                            <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-2xl flex justify-between items-center border border-slate-100 dark:border-slate-700">
                                <div>
                                    <p className="text-xs text-slate-400 uppercase font-bold">Total Fare</p>
                                    <p className="text-2xl font-bold text-slate-800 dark:text-white">
                                        {isBuyingPass ? formatCurrency(passPrice) : formatCurrency(fareDetails.totalFare * passengerCount)}
                                    </p>
                                </div>
                                <Button onClick={initiateBook} className="px-6 py-2 h-10 text-sm">
                                    {isBuyingPass ? 'Mint Pass' : 'Book Ticket'}
                                </Button>
                            </div>
                        </div>
                    ) : (
                        <div className="bg-brand-50 dark:bg-brand-900/10 p-4 rounded-2xl border border-brand-100 dark:border-brand-800/30 flex items-center justify-center gap-2 text-brand-400 text-sm font-medium">
                            <Search size={16} /> Enter location to see buses
                        </div>
                    )}
                </div>

                {/* SECONDARY FEATURES ROW */}
                <div className="grid grid-cols-2 gap-4">
                    <button onClick={() => setCurrentView('BOOK_RENTAL')} className="bg-white dark:bg-slate-900 p-4 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-800 flex flex-col items-center gap-2 hover:border-brand-200 transition-all">
                        <div className="w-10 h-10 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 rounded-full flex items-center justify-center">
                            <Car size={20} />
                        </div>
                        <span className="text-xs font-bold dark:text-white">Private Charter</span>
                    </button>
                    <button onClick={() => setCurrentView('BOOK_PARCEL')} className="bg-white dark:bg-slate-900 p-4 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-800 flex flex-col items-center gap-2 hover:border-brand-200 transition-all">
                        <div className="w-10 h-10 bg-orange-50 dark:bg-orange-900/30 text-orange-600 rounded-full flex items-center justify-center">
                            <Package size={20} />
                        </div>
                        <span className="text-xs font-bold dark:text-white">Send Parcel</span>
                    </button>
                </div>
            </div>
        )}

        {/* RENTAL FLOW */}
        {currentView === 'BOOK_RENTAL' && (
            <div className="animate-in slide-in-from-right-4">
                <div className="flex items-center gap-2 mb-6">
                    <button onClick={resetToDashboard} className="p-2 hover:bg-slate-100 rounded-full"><ArrowLeft size={20} /></button>
                    <h2 className="text-xl font-bold dark:text-white">Private Charter</h2>
                </div>
                
                <div className="space-y-4">
                    {RENTAL_FLEET.map(vehicle => (
                            <div 
                                key={vehicle.id}
                                onClick={() => { setSelectedVehicle(vehicle); setFromLocation(null); /* Reset loc to force selection */ }}
                                className={`p-4 rounded-2xl border-2 transition-all cursor-pointer flex items-center justify-between bg-white dark:bg-slate-900 ${selectedVehicle?.id === vehicle.id ? 'border-indigo-500 ring-1 ring-indigo-500' : 'border-transparent shadow-sm'}`}
                            >
                                <div className="flex items-center gap-4">
                                    <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-full flex items-center justify-center">
                                        {getRentalIcon(vehicle.imageIcon)}
                                    </div>
                                    <div>
                                        <h4 className="font-bold text-sm dark:text-white">{vehicle.type}</h4>
                                        <p className="text-xs text-slate-500">{vehicle.model}</p>
                                    </div>
                                </div>
                                <div className="text-right">
                                    <p className="font-bold text-indigo-600">₹{vehicle.ratePerKm}/km</p>
                                </div>
                            </div>
                        ))}
                </div>

                {selectedVehicle && (
                    <div className="mt-6 glass-panel rounded-[32px] p-6 animate-fade-in">
                        <div className="space-y-6 mb-6">
                            <LocationSelector label="Pickup" onSelect={setFromLocation} />
                            <LocationSelector label="Drop" onSelect={setToLocation} />
                        </div>
                        <Button fullWidth variant="primary" disabled={!fromLocation || !toLocation} onClick={initiateBook}>
                            Estimate & Book
                        </Button>
                    </div>
                )}
            </div>
        )}

        {/* PARCEL FLOW */}
        {currentView === 'BOOK_PARCEL' && (
            <div className="animate-in slide-in-from-right-4">
                <div className="flex items-center gap-2 mb-6">
                    <button onClick={resetToDashboard} className="p-2 hover:bg-slate-100 rounded-full"><ArrowLeft size={20} /></button>
                    <h2 className="text-xl font-bold dark:text-white">Send Parcel</h2>
                </div>
                <div className="glass-panel rounded-[32px] p-6 shadow-xl border border-white/50">
                    <div className="space-y-6 mb-6">
                        <LocationSelector label="Pickup From" onSelect={setFromLocation} />
                        <LocationSelector label="Deliver To" onSelect={setToLocation} />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-3 mb-6">
                        <div onClick={() => setLogisticsItemType('BOX_SMALL')} className={`p-4 rounded-xl border-2 cursor-pointer text-center ${logisticsItemType === 'BOX_SMALL' ? 'border-orange-500 bg-orange-50 text-orange-700' : 'border-slate-100 bg-white'}`}>
                            <Box size={24} className="mx-auto mb-2" />
                            <span className="text-xs font-bold">Small Box</span>
                        </div>
                        <div onClick={() => setLogisticsItemType('SACK_GRAIN')} className={`p-4 rounded-xl border-2 cursor-pointer text-center ${logisticsItemType === 'SACK_GRAIN' ? 'border-orange-500 bg-orange-50 text-orange-700' : 'border-slate-100 bg-white'}`}>
                            <Package size={24} className="mx-auto mb-2" />
                            <span className="text-xs font-bold">Heavy Sack</span>
                        </div>
                    </div>

                    <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-xl flex justify-between items-center mb-6">
                            <span className="text-xs font-bold uppercase text-slate-500">Delivery Cost</span>
                            <span className="text-2xl font-bold text-orange-600">₹{logisticsPrice}</span>
                    </div>

                    <Button fullWidth variant="primary" disabled={!fromLocation || !toLocation} onClick={initiateBook}>
                        Create Smart Contract
                    </Button>
                </div>
            </div>
        )}

        {/* PASSES TAB (My Passes) */}
        {activeTab === 'PASSES' && (
            <div className="animate-fade-in space-y-4 pt-4 px-2">
                <h2 className="text-xl font-bold dark:text-white mb-4">My Digital Passes</h2>
                {myPasses.length === 0 ? (
                    <div className="text-center py-10 text-slate-400">
                        <TicketIcon size={48} className="mx-auto mb-4 opacity-30" />
                        <p>No active passes.</p>
                        <button onClick={() => { setActiveTab('HOME'); setCurrentView('DASHBOARD'); setIsBuyingPass(true); }} className="text-brand-600 font-bold mt-2">Buy One Now</button>
                    </div>
                ) : (
                    myPasses.map(pass => (
                        <div key={pass.id} className="relative bg-slate-900 text-white p-6 rounded-3xl overflow-hidden shadow-2xl border border-slate-700 mb-4">
                            <div className="absolute -top-10 -right-10 w-32 h-32 bg-brand-500/30 blur-3xl rounded-full"></div>
                            <div className="relative z-10 flex justify-between items-start mb-6">
                                <div className="flex items-center gap-2">
                                    <Bus className="text-emerald-400" size={16} />
                                    <span className="font-bold tracking-widest text-xs opacity-80">MONTHLY PASS</span>
                                </div>
                                <span className="font-mono text-[10px] opacity-50">{pass.id}</span>
                            </div>
                            <div className="relative z-10 mb-6">
                                <h3 className="text-2xl font-bold mb-1">{pass.from} <span className="text-slate-400 text-lg">to</span> {pass.to}</h3>
                                <span className="bg-white/10 px-2 py-1 rounded text-[10px] font-bold">{pass.seatConfig}</span>
                            </div>
                            <div className="relative z-10 mt-4 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                                <div className="h-full bg-gradient-to-r from-emerald-400 to-brand-500" style={{ width: `${((30 - pass.usedDates.length) / 30) * 100}%` }}></div>
                            </div>
                            <p className="text-right text-[10px] mt-2 opacity-70">{30 - pass.usedDates.length} Days Remaining</p>
                        </div>
                    ))
                )}
            </div>
        )}

        {/* PROFILE TAB (Integrated UserProfile) */}
        {activeTab === 'PROFILE' && (
            <UserProfile user={user} onBack={() => handleTabChange('HOME')} />
        )}

        {/* Confirmation & Payment Modals */}
        <Modal 
            isOpen={showConfirm} 
            onClose={() => setShowConfirm(false)} 
            onConfirm={handleReviewConfirm} 
            title="Confirm Details" 
            confirmLabel={'Proceed to Pay'} 
            isLoading={isBooking}
        >
            <div className="bg-slate-50 dark:bg-slate-800 p-6 rounded-2xl text-center">
                <p className="text-xs text-slate-500 uppercase font-bold mb-2">Total Amount</p>
                <p className="text-4xl font-bold text-slate-800 dark:text-white mb-6">
                    {currentView === 'BOOK_RENTAL' ? formatCurrency(rentalPrice) : (currentView === 'BOOK_PARCEL' ? formatCurrency(logisticsPrice) : (isBuyingPass ? formatCurrency(passPrice) : formatCurrency((fareDetails?.totalFare || 0) * passengerCount)))}
                </p>
                
                {/* Simple Payment Select */}
                <div className="flex gap-3 justify-center">
                    <button onClick={() => setPaymentMethod(PaymentMethod.CASH)} className={`px-4 py-2 rounded-xl text-xs font-bold border ${paymentMethod === PaymentMethod.CASH ? 'bg-brand-100 border-brand-500 text-brand-700' : 'bg-white border-slate-200'}`}>Cash</button>
                    <button onClick={() => setPaymentMethod(PaymentMethod.ONLINE)} className={`px-4 py-2 rounded-xl text-xs font-bold border ${paymentMethod === PaymentMethod.ONLINE ? 'bg-brand-100 border-brand-500 text-brand-700' : 'bg-white border-slate-200'}`}>Online</button>
                    <button onClick={() => setPaymentMethod(PaymentMethod.GRAMCOIN)} className={`px-4 py-2 rounded-xl text-xs font-bold border ${paymentMethod === PaymentMethod.GRAMCOIN ? 'bg-yellow-100 border-yellow-500 text-yellow-700' : 'bg-white border-slate-200'}`}>GramCoin</button>
                </div>
            </div>
        </Modal>

        <PaymentGatewayModal 
            isOpen={showPaymentGateway} 
            onClose={() => setShowPaymentGateway(false)} 
            onSuccess={() => completeBooking(PaymentMethod.ONLINE, TicketStatus.PAID)} 
            amount={currentView === 'BOOK_RENTAL' ? rentalPrice : (currentView === 'BOOK_PARCEL' ? logisticsPrice : (isBuyingPass ? passPrice : (fareDetails?.totalFare || 0) * passengerCount))} 
        />

        {showToast && (
            <div className="fixed top-12 left-1/2 -translate-x-1/2 z-[100] animate-in slide-in-from-top-4">
            <div className="bg-emerald-500 text-white px-6 py-3 rounded-full shadow-xl flex items-center gap-2 font-bold text-sm">
                <Check size={18} /> Confirmed!
            </div>
            </div>
        )}
        </div>

        {/* FIXED BOTTOM NAV - Moved outside animated container to prevent scrolling issues */}
        <BottomNav activeTab={activeTab} onTabChange={handleTabChange} />
    </>
  );
};
