
import React, { useRef, useState, useEffect } from 'react';
import { MapPin, Navigation, Search, X, Mic, MicOff } from 'lucide-react';
import { ALL_LOCATIONS } from '../constants';
import { LocationData } from '../types';

interface LocationSelectorProps {
  label: string;
  onSelect: (data: LocationData) => void;
  icon?: React.ReactNode;
  disabled?: boolean;
}

export const LocationSelector: React.FC<LocationSelectorProps> = ({ 
  label, onSelect, icon, disabled = false
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [isLocating, setIsLocating] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const wrapperRef = useRef<HTMLDivElement>(null);

  // Performance optimized filtering
  const filteredLocations = React.useMemo(() => {
    if (!searchTerm) return [];
    const lowerTerm = searchTerm.toLowerCase();
    return ALL_LOCATIONS.filter(loc => 
      loc.name.toLowerCase().includes(lowerTerm) ||
      loc.villageCode.includes(lowerTerm)
    ).slice(0, 20); // Limit results for speed
  }, [searchTerm]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelect = (location: LocationData) => {
    setSearchTerm(location.name);
    setIsOpen(false);
    onSelect(location);
  };

  const handleClear = () => {
    setSearchTerm('');
    setIsOpen(true);
  };

  const handleVoiceSearch = () => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      alert("Voice search not supported in this browser.");
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    const recognition = new SpeechRecognition();

    recognition.lang = 'hi-IN'; // Prioritize Hindi/Indian English accents
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    recognition.onstart = () => {
      setIsListening(true);
      setSearchTerm('Listening...');
    };

    recognition.onresult = (event: any) => {
      const speechResult = event.results[0][0].transcript;
      setSearchTerm(speechResult);
      setIsListening(false);
      setIsOpen(true);
    };

    recognition.onspeechend = () => {
      recognition.stop();
      setIsListening(false);
    };

    recognition.onerror = (event: any) => {
      console.error('Speech recognition error', event.error);
      setIsListening(false);
      setSearchTerm('');
    };

    recognition.start();
  };

  const handleAutoDetect = () => {
    if (!navigator.geolocation) return;
    setIsLocating(true);
    
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords;
        
        let minDistance = Infinity;
        let nearest: LocationData | null = null;

        // Find nearest village from ALL_LOCATIONS
        ALL_LOCATIONS.forEach(loc => {
          const dist = Math.sqrt(
            Math.pow(loc.lat - latitude, 2) + Math.pow(loc.lng - longitude, 2)
          );
          if (dist < minDistance) {
            minDistance = dist;
            nearest = loc;
          }
        });

        if (nearest) {
          handleSelect(nearest);
        } else {
          alert("No village found nearby.");
        }
        setIsLocating(false);
      },
      (err) => {
        console.error(err);
        setIsLocating(false);
        alert("GPS access denied.");
      }
    );
  };

  return (
    <div className={`relative space-y-2 ${disabled ? 'opacity-60 pointer-events-none' : ''}`} ref={wrapperRef}>
      <div className="flex justify-between items-center pl-1">
        <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">{label}</label>
        {!disabled && (
          <div className="flex gap-2">
            <button 
              onClick={(e) => { e.stopPropagation(); handleAutoDetect(); }}
              className="text-[10px] flex items-center gap-1 text-brand-600 dark:text-brand-400 bg-brand-50 dark:bg-brand-900/30 px-2 py-1 rounded-full hover:bg-brand-100 transition-colors"
            >
              {isLocating ? <span className="animate-spin">⌛</span> : <Navigation size={10} />}
              {isLocating ? 'Locating...' : 'Auto-detect'}
            </button>
          </div>
        )}
      </div>
      
      <div className="relative group">
        <div className="absolute left-4 top-1/2 -translate-y-1/2 text-brand-500 dark:text-neon-cyan transition-colors z-10">
          {icon || <MapPin size={18} />}
        </div>
        
        <input
          type="text"
          placeholder={isListening ? "Speak now..." : "Type Village Name..."}
          value={searchTerm}
          onChange={(e) => {
             setSearchTerm(e.target.value);
             if (!isOpen) setIsOpen(true);
          }}
          onClick={() => !disabled && setIsOpen(true)}
          className={`w-full pl-12 pr-12 py-4 bg-white/50 dark:bg-slate-900/50 border ${isListening ? 'border-brand-500 ring-2 ring-brand-500/20' : 'border-white/60 dark:border-slate-700'} rounded-xl text-lg font-medium shadow-sm focus:border-brand-500 outline-none transition-all backdrop-blur-sm text-slate-900 dark:text-white`}
          disabled={disabled}
        />
        
        {/* Voice Button or Clear Button */}
        <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-2">
          {searchTerm && !disabled && !isListening && (
            <button onClick={handleClear} className="p-1 text-slate-400 hover:text-slate-600">
              <X size={16} />
            </button>
          )}
          
          {!disabled && (
            <button 
              onClick={handleVoiceSearch} 
              className={`p-2 rounded-full transition-all ${isListening ? 'bg-red-500 text-white animate-pulse shadow-lg shadow-red-500/30' : 'text-slate-400 hover:text-brand-500 hover:bg-brand-50 dark:hover:bg-slate-800'}`}
              title="Voice Search"
            >
              {isListening ? <MicOff size={16} /> : <Mic size={16} />}
            </button>
          )}
        </div>

        {isOpen && !disabled && filteredLocations.length > 0 && (
          <div className="absolute z-50 left-0 right-0 top-full mt-2 bg-white dark:bg-slate-900 rounded-xl shadow-2xl border border-slate-100 dark:border-slate-700 overflow-hidden animate-fade-in max-h-64 overflow-y-auto">
            {filteredLocations.map((loc) => (
              <div 
                key={`${loc.villageCode}-${loc.name}`}
                onMouseDown={(e) => {
                  e.preventDefault(); // Prevent input blur which would close the dropdown
                  handleSelect(loc);
                }}
                className="px-4 py-3 hover:bg-brand-50 dark:hover:bg-slate-800 cursor-pointer border-b border-slate-50 dark:border-slate-800 last:border-0 flex justify-between items-center"
              >
                <div>
                  <p className="text-sm font-bold text-slate-800 dark:text-white">{loc.name}</p>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400">{loc.panchayat}, {loc.block}</p>
                </div>
                <span className="text-[9px] font-mono bg-slate-100 dark:bg-slate-700 px-1.5 py-0.5 rounded text-slate-500">
                  {loc.villageCode}
                </span>
              </div>
            ))}
          </div>
        )}
        
        {isOpen && !disabled && searchTerm && filteredLocations.length === 0 && !isListening && (
           <div className="absolute z-50 left-0 right-0 top-full mt-2 bg-white dark:bg-slate-900 rounded-xl shadow-xl p-4 text-center text-sm text-slate-400">
              No village found named "{searchTerm}"
           </div>
        )}
      </div>
    </div>
  );
};
