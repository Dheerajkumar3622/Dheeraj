
import React, { useEffect, useState } from 'react';
import { STOPS, STOP_COORDINATES } from '../constants';
import { subscribeToUpdates, getActiveBuses } from '../services/transportService';
import { Bus, AlertTriangle, Clock, Wrench, PlayCircle, Search, MapPin, User as UserIcon, Armchair } from 'lucide-react';
import { BusState, VehicleStatusLabel, GeoLocation } from '../types';

interface LiveTrackerProps {
  desiredPath?: string[];
}

const calculateDistance = (lat1: number, lng1: number, lat2: number, lng2: number) => {
  const R = 6371; 
  const dLat = (lat2 - lat1) * (Math.PI / 180);
  const dLng = (lng2 - lng1) * (Math.PI / 180);
  const a = 
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * (Math.PI / 180)) * Math.cos(lat2 * (Math.PI / 180)) * 
    Math.sin(dLng / 2) * Math.sin(dLng / 2); 
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)); 
  return R * c; 
};

export const LiveTracker: React.FC<LiveTrackerProps> = ({ desiredPath }) => {
  const [buses, setBuses] = useState<BusState[]>([]);
  const [userLocation, setUserLocation] = useState<GeoLocation | null>(null);

  useEffect(() => {
    setBuses(getActiveBuses());
    subscribeToUpdates(
      () => {},
      (updatedBuses) => {
        setBuses(updatedBuses);
      }
    );

    // Track User Location for "Where is my bus relative to me"
    if (navigator.geolocation) {
      const watchId = navigator.geolocation.watchPosition(
        (pos) => {
          setUserLocation({
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
            timestamp: Date.now()
          });
        },
        (err) => console.log("GPS Error", err),
        { enableHighAccuracy: true }
      );
      return () => navigator.geolocation.clearWatch(watchId);
    }
  }, []);

  // Filter Buses Logic
  const filteredBuses = React.useMemo(() => {
    if (!desiredPath || desiredPath.length < 2) return buses;

    const startLocation = desiredPath[0];
    const endLocation = desiredPath[desiredPath.length - 1];

    return buses.filter(bus => {
      if (!bus.activePath || bus.activePath.length === 0) return false;
      const startIndex = bus.activePath.indexOf(startLocation);
      const endIndex = bus.activePath.indexOf(endLocation);
      return startIndex !== -1 && endIndex !== -1 && startIndex < endIndex;
    });
  }, [buses, desiredPath]);

  const isAnyOnline = filteredBuses.length > 0;
  const activeBus = filteredBuses[0];
  
  const displayStops = (desiredPath && desiredPath.length > 0) ? desiredPath : (isAnyOnline && activeBus.activePath ? activeBus.activePath : STOPS.slice(0, 5));

  // --- "WHERE IS MY TRAIN" LOGIC ---
  // Calculates the exact percentage (0-100%) of the bus along the visible route line
  const calculateBusProgress = () => {
    if (!activeBus || !activeBus.location || !activeBus.activePath) return 0;

    const currentStopName = activeBus.activePath[activeBus.currentStopIndex];
    const nextStopName = activeBus.activePath[activeBus.currentStopIndex + 1];

    // Identify indices in the *Displayed* stops array to position on UI
    const uiStartIndex = displayStops.indexOf(currentStopName);
    
    // If bus hasn't reached the first displayed stop yet
    if (uiStartIndex === -1) {
        // Check if we are past the route end? (Assuming simplified forward logic for now)
        return 0; 
    }

    // Coordinates
    const prevCoords = STOP_COORDINATES[currentStopName];
    const nextCoords = STOP_COORDINATES[nextStopName];

    if (!prevCoords || !nextCoords) {
        return (uiStartIndex / (displayStops.length - 1)) * 100;
    }

    const totalSegmentDist = calculateDistance(prevCoords.lat, prevCoords.lng, nextCoords.lat, nextCoords.lng);
    const busDistFromPrev = calculateDistance(prevCoords.lat, prevCoords.lng, activeBus.location.lat, activeBus.location.lng);
    
    const segmentProgress = totalSegmentDist > 0 ? (busDistFromPrev / totalSegmentDist) : 0;

    const segmentWidth = 100 / (displayStops.length - 1);
    const globalProgress = (uiStartIndex * segmentWidth) + (segmentProgress * segmentWidth);

    return Math.min(Math.max(globalProgress, 0), 100);
  };

  // Calculate User Position on the line
  const calculateUserProgress = () => {
      if (!userLocation || displayStops.length < 2) return -1;
      
      let closestStopIndex = 0;
      let minDist = Infinity;

      displayStops.forEach((stop, idx) => {
          const coords = STOP_COORDINATES[stop];
          if (coords) {
              const d = calculateDistance(userLocation.lat, userLocation.lng, coords.lat, coords.lng);
              if (d < minDist) {
                  minDist = d;
                  closestStopIndex = idx;
              }
          }
      });

      return (closestStopIndex / (displayStops.length - 1)) * 100;
  };

  const calculateETA = () => {
     if (!activeBus || !activeBus.location || !userLocation) return null;
     const distKm = calculateDistance(activeBus.location.lat, activeBus.location.lng, userLocation.lat, userLocation.lng);
     const busProgress = calculateBusProgress();
     const userProgress = calculateUserProgress();

     if (userProgress > -1 && busProgress > userProgress) {
        return "Bus has passed";
     }
     
     const speed = activeBus.telemetry?.speed || 30;
     const timeMins = Math.round((distKm / speed) * 60);
     
     if (timeMins <= 0) return 'Arriving Now';
     if (timeMins > 60) return '> 1 hr';
     return `${timeMins} min`;
  };

  const busPosition = calculateBusProgress();
  const userPosition = calculateUserProgress();
  const eta = calculateETA();
  const seatsLeft = activeBus ? Math.max(0, (activeBus.capacity || 40) - (activeBus.occupancy || 0)) : 0;

  const getStatusColor = (status?: VehicleStatusLabel) => {
    switch(status) {
      case 'EN_ROUTE': return 'text-green-500 bg-green-100 dark:bg-green-900/30';
      case 'DELAYED': return 'text-amber-500 bg-amber-100 dark:bg-amber-900/30';
      case 'MAINTENANCE': return 'text-red-500 bg-red-100 dark:bg-red-900/30';
      default: return 'text-slate-500 bg-slate-100 dark:bg-slate-800';
    }
  };

  return (
    <div className="w-full glass-panel rounded-3xl p-6 shadow-xl mb-8 overflow-hidden relative min-h-[180px]">
      
      {/* Vacant Seats Badge */}
      {isAnyOnline && (
        <div className="absolute top-4 right-4 z-20 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md px-3 py-1.5 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 flex items-center gap-2">
            <Armchair size={14} className={seatsLeft < 5 ? "text-red-500" : "text-emerald-500"} />
            <div className="flex flex-col leading-none">
                <span className="text-[10px] font-bold dark:text-white">{seatsLeft} Seats</span>
                <span className="text-[8px] text-slate-500 font-medium">Available</span>
            </div>
        </div>
      )}

      <div className="flex justify-between items-center mb-10">
        <div>
            <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <span className="relative flex h-3 w-3">
                {isAnyOnline && <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-400 opacity-75"></span>}
                <span className={`relative inline-flex rounded-full h-3 w-3 ${isAnyOnline ? 'bg-brand-500' : 'bg-slate-400'}`}></span>
            </span>
            {eta ? `Arriving in ${eta}` : (isAnyOnline ? 'Live Tracking' : 'Waiting for bus...')}
            </h3>
            {isAnyOnline && activeBus.activePath && (
                <p className="text-[10px] text-slate-500 ml-5">
                    {activeBus.activePath[0]} <span className="text-slate-300">to</span> {activeBus.activePath[activeBus.activePath.length-1]}
                    <span className="ml-2 opacity-50">({activeBus.activePath.length} stops)</span>
                </p>
            )}
        </div>
        
        {isAnyOnline && (
           <div className="flex flex-col items-end gap-1 mt-8">
             <span className={`text-[10px] font-bold px-2 py-1 rounded flex items-center gap-1 ${getStatusColor(activeBus.status)}`}>
               {activeBus.status || 'IDLE'}
             </span>
             {activeBus.telemetry && <span className="text-[10px] font-mono bg-slate-900 text-green-400 px-2 py-1 rounded">
               {Math.round(activeBus.telemetry.speed)} KM/H
             </span>}
           </div>
        )}
      </div>

      <div className="relative overflow-x-auto pb-4 scrollbar-hide">
        <div className="relative py-8 px-2 mx-4" style={{ minWidth: `${Math.max(100, displayStops.length * 80)}px` }}>
            {/* Track Line */}
            <div className="absolute top-1/2 left-0 right-0 h-1.5 bg-slate-200 dark:bg-slate-700 -translate-y-1/2 rounded-full overflow-hidden">
                {/* Progress Fill */}
                {isAnyOnline && (
                    <div 
                        className="h-full bg-gradient-to-r from-brand-300 to-brand-600 transition-all duration-[2000ms] ease-linear" 
                        style={{ width: `${busPosition}%` }}
                    ></div>
                )}
            </div>

            {/* Stops Visualization */}
            <div className="relative z-10 flex justify-between w-full">
            {displayStops.map((stop, index) => {
                const stopPos = (index / (displayStops.length - 1)) * 100;
                const isPassed = busPosition > stopPos;
                
                return (
                <div key={stop + index} className="flex flex-col items-center gap-3 group w-20 relative">
                    <div className={`
                    relative w-3 h-3 rounded-full border-[2px] transition-all duration-500 z-10
                    ${isPassed 
                        ? 'bg-brand-500 border-brand-500' 
                        : 'bg-white dark:bg-slate-800 border-stone-300 dark:border-slate-600'}
                    `}></div>
                    
                    <span className={`text-[9px] text-center font-bold leading-tight transition-all duration-300 uppercase tracking-tighter max-w-[60px] truncate ${isPassed ? 'text-brand-600' : 'text-stone-400'}`}>
                    {stop}
                    </span>
                </div>
                );
            })}
            </div>

            {/* User Location Marker (YOU) */}
            {userPosition > -1 && (
                <div 
                    className="absolute top-1/2 -translate-y-1/2 z-20 transition-all duration-1000 -ml-3"
                    style={{ left: `${userPosition}%` }}
                >
                    <div className="flex flex-col items-center gap-1">
                        <div className="w-6 h-6 bg-blue-500 rounded-full border-2 border-white shadow-lg flex items-center justify-center text-white animate-pulse">
                            <UserIcon size={12} fill="currentColor" />
                        </div>
                        <span className="text-[9px] font-bold text-blue-500 bg-white/90 dark:bg-slate-900/90 px-1.5 rounded shadow-sm">YOU</span>
                    </div>
                </div>
            )}

            {/* Bus Icon Animation (THE VEHICLE) */}
            {isAnyOnline ? (
            <div 
                    className="absolute top-1/2 -translate-y-1/2 z-30 transition-all duration-[2000ms] ease-linear -ml-4"
                    style={{ left: `${busPosition}%` }}
            >
                <div className="flex flex-col items-center">
                    <div className={`text-white p-2 rounded-full shadow-lg shadow-brand-500/40 relative ${activeBus.status === 'MAINTENANCE' ? 'bg-red-500' : activeBus.status === 'DELAYED' ? 'bg-amber-500' : 'bg-brand-600'}`}>
                        <Bus size={18} fill="currentColor" />
                        {/* Headlight Effect */}
                        <div className="absolute right-0 top-1/2 -translate-y-1/2 w-8 h-6 bg-yellow-200/30 blur-md rounded-full -z-10"></div>
                    </div>
                </div>
            </div>
            ) : desiredPath && desiredPath.length > 0 ? (
            <div className="absolute top-1/2 -translate-y-1/2 left-1/2 -translate-x-1/2 z-20">
                <div className="bg-slate-100 dark:bg-slate-800 px-3 py-1 rounded-full text-xs text-slate-500 flex items-center gap-1">
                <Search size={12} className="animate-pulse" />
                Locating bus...
                </div>
            </div>
            ) : null}
        </div>
      </div>
    </div>
  );
};
