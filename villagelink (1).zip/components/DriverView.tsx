
import React, { useState, useEffect, useMemo } from 'react';
import { getStoredTickets, updateTicketStatus, subscribeToUpdates, broadcastBusLocation, registerDriverOnNetwork, disconnectDriver, verifyPass, getRentalRequests, respondToRental, toggleDriverCharter } from '../services/transportService';
import { findDetailedPath, calculatePathDistance } from '../services/graphService';
import { Ticket, TicketStatus, PaymentMethod, User, LocationData, Pass, DeviationProposal, RentalBooking, TelemetryData, VehicleComponentHealth } from '../types';
import { checkForRouteDeviations, analyzeCrowdImage, analyzeDriverFatigue, recognizeFace } from '../services/mlService';
import { addToTrustChain, getVehicleHealth } from '../services/blockchainService';
import { verifySignature } from '../services/securityService';
import { getDigitalTwinData, analyzeDriverFace } from '../services/advancedFeatures';
import { Button } from './Button';
import { ArrowRight, Wallet, Smartphone, XCircle, Play, Square, ScanLine, AlertTriangle, UserCheck, Zap, Camera, Car, Activity, EyeOff, ScanFace, Box, ShieldCheck, Check, Users, MapPin, MonitorSmartphone, Settings, Clock, Lock } from 'lucide-react';
import { LocationSelector } from './LocationSelector';
import { Modal } from './Modal';

interface DriverViewProps {
  user: User;
}

interface TripConfig {
  isActive: boolean;
  startLocation: LocationData | null;
  endLocation: LocationData | null;
  path: string[]; 
  totalDistance: number;
}

export const DriverView: React.FC<DriverViewProps> = ({ user }) => {
  const [viewMode, setViewMode] = useState<'BUS' | 'CHARTER'>('BUS');
  
  // Verification Check
  if (!user.isVerified) {
      return (
          <div className="min-h-screen flex flex-col items-center justify-center p-6 text-center animate-fade-in bg-slate-50 dark:bg-black">
              <div className="w-24 h-24 bg-amber-100 dark:bg-amber-900/30 rounded-full flex items-center justify-center mb-6 animate-pulse">
                  <Clock size={48} className="text-amber-500" />
              </div>
              <h2 className="text-2xl font-bold dark:text-white mb-2">Verification Pending</h2>
              <p className="text-slate-500 dark:text-slate-400 mb-8 max-w-xs">
                  Your driver profile is currently under review by the Master Admin. You will be able to access the dashboard once verified.
              </p>
              <div className="bg-slate-100 dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 w-full max-w-xs text-left">
                  <p className="text-xs font-bold uppercase text-slate-400 mb-2">Application Details</p>
                  <div className="flex justify-between text-sm dark:text-slate-200 mb-1">
                      <span>Name:</span> <span className="font-bold">{user.name}</span>
                  </div>
                  <div className="flex justify-between text-sm dark:text-slate-200 mb-1">
                      <span>ID:</span> <span className="font-mono">{user.id}</span>
                  </div>
                  <div className="flex justify-between text-sm dark:text-slate-200">
                      <span>Status:</span> <span className="text-amber-500 font-bold flex items-center gap-1"><Lock size={12} /> Unverified</span>
                  </div>
              </div>
              <button onClick={() => window.location.reload()} className="mt-8 text-brand-600 font-bold text-sm">Refresh Status</button>
          </div>
      );
  }

  // Bus Mode State
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [ticketIdInput, setTicketIdInput] = useState('');
  const [isScanning, setIsScanning] = useState(false);
  const [scannedTicket, setScannedTicket] = useState<Ticket | null>(null);
  const [scannedPass, setScannedPass] = useState<Pass | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  
  // Charter Mode State
  const [isCharterAvailable, setIsCharterAvailable] = useState(false);
  const [rentalRequests, setRentalRequests] = useState<RentalBooking[]>([]);

  // ML State (Route Deviation & Safety)
  const [deviation, setDeviation] = useState<DeviationProposal | null>(null);
  const [showCamera, setShowCamera] = useState(false);
  const [cameraMode, setCameraMode] = useState<'CROWD' | 'FACE_AUTH' | 'PARCEL'>('CROWD'); 
  const [isAnalyzingCrowd, setIsAnalyzingCrowd] = useState(false);
  const [crowdResult, setCrowdResult] = useState<{detected: number, expected: number} | null>(null);
  
  // Safety Monitor State (Feature 4 - Edge AI)
  const [isSafetyMonitorActive, setIsSafetyMonitorActive] = useState(false);
  const [fatigueAlert, setFatigueAlert] = useState(false);

  // Digital Twin State (Feature 5)
  const [showDigitalTwin, setShowDigitalTwin] = useState(false);
  const [vehicleComponents, setVehicleComponents] = useState<VehicleComponentHealth[]>([]);

  const [tripConfig, setTripConfig] = useState<TripConfig>({
     isActive: false, startLocation: null, endLocation: null, path: [], totalDistance: 0
  });
  const [isOnline, setIsOnline] = useState(false);
  const [currentStopIndex, setCurrentStopIndex] = useState(0);

  // Calculate live occupancy (Boarded Passengers)
  const currentOccupancy = useMemo(() => {
    return tickets.filter(t => t.status === TicketStatus.BOARDED).reduce((acc, t) => acc + t.passengerCount, 0);
  }, [tickets]);

  useEffect(() => {
    let interval: any;
    if (isOnline && tripConfig.isActive) {
      interval = setInterval(() => {
        
        broadcastBusLocation({
          driverId: user.id,
          isOnline: true,
          activePath: tripConfig.path,
          currentStopIndex: currentStopIndex,
          status: 'EN_ROUTE',
          location: tripConfig.startLocation ? { lat: tripConfig.startLocation.lat, lng: tripConfig.startLocation.lng, timestamp: Date.now() } : null,
          telemetry: undefined, // IoT Removed
          capacity: user.vehicleCapacity || 40, // Default to 40 if not set
          occupancy: currentOccupancy
        });
        
        // Feature 2: Smart Stop Clustering Logic (simulated check)
        if (!deviation && Math.random() > 0.95) {
            const proposal = checkForRouteDeviations(tripConfig.path[currentStopIndex]);
            if (proposal) setDeviation(proposal);
        }

        // Feature 4: Safety Monitor (Edge AI Simulation)
        if (isSafetyMonitorActive && !fatigueAlert && Math.random() > 0.99) {
             // Simulate calling local edge model
             const isDrowsy = analyzeDriverFace(); 
             if (isDrowsy) setFatigueAlert(true);
        }
      }, 2000);
    }
    return () => clearInterval(interval);
  }, [isOnline, tripConfig, user.id, currentStopIndex, deviation, isSafetyMonitorActive, fatigueAlert, currentOccupancy, user.vehicleCapacity]);

  useEffect(() => {
    setTickets(getStoredTickets());
    subscribeToUpdates(() => setTickets(getStoredTickets()), () => {});
    const rentalInterval = setInterval(async () => {
        if (viewMode === 'CHARTER' && isCharterAvailable) {
            const reqs = await getRentalRequests();
            setRentalRequests(reqs);
        }
    }, 5000);
    return () => { disconnectDriver(user.id); clearInterval(rentalInterval); };
  }, [user.id, viewMode, isCharterAvailable]);

  // Computed: Waiting Passengers Logic
  const waitingPassengers = useMemo<Record<string, number>>(() => {
    if (!tripConfig.isActive) return {};
    const counts: Record<string, number> = {};
    // Filter pending tickets that match stops in the current path
    tickets.filter(t => t.status === TicketStatus.PENDING).forEach(t => {
        if (tripConfig.path.includes(t.from)) {
            counts[t.from] = (counts[t.from] || 0) + t.passengerCount;
        }
    });
    return counts;
  }, [tickets, tripConfig]);

  const totalWaiting = Object.values(waitingPassengers).reduce((a: number, b: number) => a+b, 0);

  const handleStartTrip = () => {
    if (!tripConfig.startLocation || !tripConfig.endLocation) return;
    
    // UPDATED: Use detailed path for better accuracy and village visualization
    const path = findDetailedPath(tripConfig.startLocation.name, tripConfig.endLocation.name);
    const dist = path ? calculatePathDistance(path) : 0;
    const finalPath = path && path.length > 0 ? path : [tripConfig.startLocation.name, tripConfig.endLocation.name];
    
    setTripConfig(prev => ({ ...prev, isActive: true, path: finalPath, totalDistance: dist }));
    setIsOnline(true);
    setIsSafetyMonitorActive(true); // Auto-enable safety
    registerDriverOnNetwork(user);
  };

  const handleEndTrip = () => {
    setTripConfig({ isActive: false, startLocation: null, endLocation: null, path: [], totalDistance: 0 });
    setIsOnline(false);
    setIsSafetyMonitorActive(false);
    disconnectDriver(user.id);
  };

  const handleValidate = async () => {
    setError(null); setSuccessMsg(null); setScannedTicket(null); setScannedPass(null); setIsScanning(true);
    const rawInput = ticketIdInput.trim().toUpperCase();
    if (!rawInput) { setError("Enter ID"); setIsScanning(false); return; }

    // TrustChain Logistics Scan
    if (rawInput.startsWith('PKG-')) {
        addToTrustChain({ type: 'PARCEL_HANDOVER', parcelId: rawInput, driverId: user.id, location: 'BUS_PICKUP' });
        setSuccessMsg("PARCEL ON CHAIN");
        setIsScanning(false);
        return;
    }

    const isExplicitTicket = rawInput.startsWith('TK-');
    const isExplicitPass = rawInput.startsWith('PASS-');
    
    // Try finding ticket locally
    if (!isExplicitPass) {
        const ticketMatch = tickets.find(t => t.id === rawInput || (!isExplicitTicket && t.id === `TK-${rawInput}`));
        if (ticketMatch) {
            if (ticketMatch.status === TicketStatus.COMPLETED) { setError("Ticket COMPLETED."); setIsScanning(false); return; }
            
            // v13.0 Security: Verify Digital Signature
            if (ticketMatch.digitalSignature) {
                const isValid = await verifySignature(ticketMatch, ticketMatch.digitalSignature);
                if (!isValid) {
                    setError("⚠️ INVALID SIGNATURE: Potential Forgery");
                    setIsScanning(false); 
                    return;
                }
            }

            setScannedTicket(ticketMatch); setIsScanning(false); return;
        }
    }
    // Try finding pass via API
    if (!isExplicitTicket) {
        const passIdToCheck = isExplicitPass ? rawInput : `PASS-${rawInput}`;
        try {
            const res = await verifyPass(passIdToCheck);
            if (res.success && res.pass) { setScannedPass(res.pass); setSuccessMsg("PASS VERIFIED"); setIsScanning(false); return; }
        } catch (e) { console.error(e); }
    }
    setError(`ID "${rawInput}" not found.`); setIsScanning(false);
  };

  const processBoarding = (method: PaymentMethod, status: TicketStatus) => {
    if (!scannedTicket) return;
    updateTicketStatus(scannedTicket.id, method, status, user.id);
    setSuccessMsg("Updated!");
    setTimeout(() => { setScannedTicket(null); setTicketIdInput(''); setSuccessMsg(null); }, 2000);
  };

  const toggleCharter = async () => {
      const newState = !isCharterAvailable;
      setIsCharterAvailable(newState);
      await toggleDriverCharter(user.id, newState);
  };

  const handleRentalResponse = async (id: string, accept: boolean) => {
      await respondToRental(id, user.id, accept ? 'ACCEPTED' : 'REJECTED');
      setRentalRequests(prev => prev.filter(r => r.id !== id));
      if (accept) alert("Charter Booked! Proceed to pickup.");
  };

  const openDigitalTwin = () => {
      const data = getDigitalTwinData();
      setVehicleComponents(data);
      setShowDigitalTwin(true);
  };

  return (
    <div className="max-w-md mx-auto pb-32 animate-fade-in font-sans relative">
       {fatigueAlert && <div className="fixed inset-0 z-[100] bg-red-600 flex flex-col items-center justify-center text-white animate-pulse"><EyeOff size={120} className="mb-6" /><h1 className="text-4xl font-black mb-2 uppercase tracking-widest text-center">Fatigue Detected</h1><p className="text-xl font-bold mb-8 opacity-90">Please stop the vehicle immediately.</p><button onClick={() => setFatigueAlert(false)} className="bg-white text-red-600 px-8 py-4 rounded-full font-bold text-xl shadow-xl hover:scale-105 transition-transform">I am Awake</button></div>}
       
       {/* Edge AI Safety Monitor Overlay */}
       {isSafetyMonitorActive && (
           <div className="fixed top-20 right-4 z-40 bg-black/80 backdrop-blur text-white px-3 py-2 rounded-xl flex items-center gap-2 border border-white/10 shadow-xl">
               <div className="relative">
                   <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                   <div className="absolute inset-0 bg-green-500 rounded-full animate-ping opacity-50"></div>
               </div>
               <div className="text-[10px] leading-tight">
                   <span className="font-bold block">Safety AI</span>
                   <span className="text-slate-400">Monitoring Eyes</span>
               </div>
           </div>
       )}

       <div className="mb-6 bg-slate-900 text-white p-4 rounded-2xl shadow-lg border border-slate-700">
         <div className="flex justify-between items-center">
            <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-brand-600 flex items-center justify-center font-bold text-lg">
                    {user.name.charAt(0)}
                </div>
                <div>
                    <h2 className="text-base font-bold leading-none">Cpt. {user.name.split(' ')[0]}</h2>
                    <div className="flex items-center gap-2 text-slate-400 text-[10px] font-bold uppercase tracking-wider mt-1">
                        <span>{viewMode === 'BUS' ? 'Public Transport' : 'Private Charter'}</span>
                        <span className="flex items-center gap-1 text-emerald-400 border border-emerald-500/50 px-1.5 py-0.5 rounded-md"><ShieldCheck size={10} /> Verified Safe</span>
                    </div>
                </div>
            </div>
            <div className={`px-3 py-1.5 rounded-lg text-[10px] font-bold border flex items-center gap-2 ${isOnline || isCharterAvailable ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/50' : 'bg-slate-800 text-slate-500 border-slate-700'}`}>
                <div className={`w-2 h-2 rounded-full ${(isOnline || isCharterAvailable) ? 'bg-emerald-400 animate-pulse' : 'bg-slate-500'}`}></div>
                {(isOnline || isCharterAvailable) ? 'ACTIVE' : 'IDLE'}
            </div>
         </div>

         <div className="flex bg-slate-800 p-1 rounded-xl mt-4">
             <button onClick={() => setViewMode('BUS')} className={`flex-1 py-2 rounded-lg text-xs font-bold ${viewMode === 'BUS' ? 'bg-slate-700 text-white' : 'text-slate-500'}`}>Bus Mode</button>
             <button onClick={() => setViewMode('CHARTER')} className={`flex-1 py-2 rounded-lg text-xs font-bold ${viewMode === 'CHARTER' ? 'bg-slate-700 text-white' : 'text-slate-500'}`}>Charter Mode</button>
         </div>
       </div>

      {viewMode === 'CHARTER' ? (
        <div className="space-y-6">
            <div className="glass-panel p-6 rounded-3xl border border-white/50">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="font-bold text-lg">Charter Availability</h3>
                    <label className="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" checked={isCharterAvailable} onChange={toggleCharter} className="sr-only peer" />
                    <div className="w-11 h-6 bg-slate-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-500"></div>
                    </label>
                </div>
                <p className="text-xs text-slate-500">Turn this ON to receive private rental requests. Regular bus routes will be paused.</p>
            </div>
            {rentalRequests.map(req => (
                <div key={req.id} className="bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-xl border border-slate-100 dark:border-slate-800 animate-in slide-in-from-bottom-4">
                    <div className="flex justify-between items-start mb-4">
                        <div>
                            <span className="bg-indigo-100 text-indigo-700 px-2 py-1 rounded text-xs font-bold">NEW REQUEST</span>
                            <h3 className="text-xl font-bold mt-2 dark:text-white">{req.tripType === 'ROUND_TRIP' ? 'Round Trip' : 'One Way'}</h3>
                            <p className="text-slate-500 text-sm">{req.from} → {req.to}</p>
                        </div>
                        <div className="text-right">
                            <p className="text-2xl font-bold text-indigo-600">₹{req.totalFare}</p>
                            <p className="text-xs text-slate-400">{req.distanceKm.toFixed(1)} km</p>
                        </div>
                    </div>
                    <div className="flex gap-3">
                        <Button variant="outline" fullWidth onClick={() => handleRentalResponse(req.id, false)}>Decline</Button>
                        <Button variant="primary" fullWidth onClick={() => handleRentalResponse(req.id, true)}>Accept Ride</Button>
                    </div>
                </div>
            ))}
            {rentalRequests.length === 0 && (
                <div className="text-center py-10 text-slate-400">
                    <Car size={48} className="mx-auto mb-4 opacity-50" />
                    <p>No charter requests nearby.</p>
                </div>
            )}
        </div>
      ) : (!tripConfig.isActive ? (
        <div className="glass-panel p-8 rounded-[32px] shadow-2xl relative border border-white/50 text-center mt-12">
            <div className="w-20 h-20 bg-gradient-to-tr from-brand-600 to-purple-600 rounded-full flex items-center justify-center text-white mb-6 mx-auto shadow-xl shadow-brand-500/30">
                <Play size={36} fill="currentColor" className="ml-1" />
            </div>
            <h3 className="text-2xl font-bold dark:text-white mb-2">Begin Shift</h3>
            <p className="text-slate-500 mb-8 text-sm max-w-[240px] mx-auto">Configure your route to activate passenger tracking.</p>
            <div className="space-y-4 mb-8 text-left">
                <LocationSelector label="Start" onSelect={(data) => setTripConfig(prev => ({ ...prev, startLocation: data }))} />
                <LocationSelector label="End" onSelect={(data) => setTripConfig(prev => ({ ...prev, endLocation: data }))} />
            </div>
            <Button variant="primary" fullWidth onClick={handleStartTrip} className="h-14 text-lg rounded-xl">Initialize Route</Button>
            
            {/* Digital Twin Entry */}
            <button onClick={openDigitalTwin} className="mt-4 w-full py-3 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-center gap-2 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
                <MonitorSmartphone size={18} className="text-blue-500" />
                <span className="text-sm font-bold text-slate-600 dark:text-slate-300">Check Vehicle Health</span>
            </button>
        </div>
      ) : (
        <div className="space-y-6 animate-fade-in relative">
            
            {/* Passenger Demand Route Visualization */}
            <div className="bg-slate-900 rounded-3xl p-5 shadow-xl border border-slate-700 relative overflow-hidden">
                <div className="flex justify-between items-center mb-6 relative z-10">
                    <h3 className="text-white font-bold flex items-center gap-2">
                        <Users className="text-brand-400" size={20} />
                        Passenger Demand
                    </h3>
                    <div className="bg-brand-600 px-3 py-1 rounded-full flex items-center gap-1 text-xs font-bold text-white shadow-lg shadow-brand-500/20">
                        {totalWaiting} Waiting
                    </div>
                </div>
                
                <div className="relative z-10 max-h-60 overflow-y-auto pr-2 space-y-0">
                    {/* Route Line */}
                    <div className="absolute left-[11px] top-3 bottom-3 w-0.5 bg-slate-700 -z-10"></div>
                    
                    {tripConfig.path.map((stop, idx) => {
                        const count = waitingPassengers[stop] || 0;
                        const isPassed = idx < currentStopIndex;
                        const isCurrent = idx === currentStopIndex;
                        
                        return (
                            <div key={idx} className={`flex items-center justify-between py-3 border-b border-slate-800/50 last:border-0 ${isPassed ? 'opacity-30 grayscale' : ''}`}>
                                <div className="flex items-center gap-4">
                                    <div className={`relative w-6 h-6 rounded-full flex items-center justify-center border-2 transition-all ${isCurrent ? 'bg-emerald-500 border-emerald-500 shadow-[0_0_15px_rgba(16,185,129,0.5)] scale-110' : (count > 0 ? 'bg-brand-900 border-brand-500' : 'bg-slate-900 border-slate-600')}`}>
                                        {isCurrent && <div className="absolute inset-0 rounded-full bg-emerald-400 animate-ping opacity-75"></div>}
                                        {count > 0 && !isCurrent && <div className="w-2 h-2 rounded-full bg-brand-400"></div>}
                                    </div>
                                    <span className={`text-sm font-medium ${isCurrent ? 'text-white scale-105 origin-left' : 'text-slate-400'}`}>{stop}</span>
                                </div>
                                
                                {count > 0 && (
                                    <div className="flex items-center gap-1.5 bg-brand-500/20 px-2 py-1 rounded-lg border border-brand-500/30">
                                        <Users size={12} className="text-brand-300" />
                                        <span className="text-xs font-bold text-brand-200">{count}</span>
                                    </div>
                                )}
                            </div>
                        );
                    })}
                </div>
            </div>

            {/* Scanner UI */}
            <div className="glass-panel rounded-[32px] shadow-lg p-6 border border-white/60 relative min-h-[400px] flex flex-col">
                <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-brand-100 text-brand-600 rounded-xl flex items-center justify-center"><ScanLine size={20} /></div>
                        <h3 className="text-xl font-bold dark:text-white">Scanner</h3>
                    </div>
                    {/* Camera Mode Toggle */}
                    <div className="flex bg-slate-100 p-1 rounded-lg">
                        <button onClick={() => { setShowCamera(true); setCameraMode('CROWD'); }} className="p-2 rounded hover:bg-white"><Camera size={16} /></button>
                        <button onClick={() => { setShowCamera(true); setCameraMode('FACE_AUTH'); }} className="p-2 rounded hover:bg-white"><ScanFace size={16} /></button>
                        <button onClick={() => { setShowCamera(true); setCameraMode('PARCEL'); }} className="p-2 rounded hover:bg-white text-orange-500"><Box size={16} /></button>
                    </div>
                </div>

                {!scannedTicket && !scannedPass ? (
                <div className="flex-1 flex flex-col justify-center space-y-6">
                    <div className="relative">
                    <input type="text" value={ticketIdInput} onChange={(e) => setTicketIdInput(e.target.value)} placeholder="ENTER ID / PARCEL" className="w-full bg-slate-100 text-center text-3xl font-bold font-mono py-6 rounded-2xl outline-none uppercase tracking-widest" />
                    {ticketIdInput && <button onClick={() => setTicketIdInput('')} className="absolute right-4 top-1/2 -translate-y-1/2 p-2 text-slate-400"><XCircle size={24} /></button>}
                    </div>
                    {successMsg && <div className="bg-emerald-50 text-emerald-600 p-4 rounded-2xl text-center font-bold text-sm flex items-center justify-center gap-2"><Check size={18} /> {successMsg}</div>}
                    {error && <div className="bg-red-50 text-red-600 p-4 rounded-2xl text-center font-bold text-sm flex items-center justify-center gap-2"><AlertTriangle size={18} /> {error}</div>}
                    <Button variant="primary" fullWidth onClick={handleValidate} disabled={isScanning} className="h-16 text-xl rounded-2xl">{isScanning ? 'Checking...' : 'Check ID'}</Button>
                </div>
                ) : (
                    // ... (Existing Ticket/Pass UI)
                    <div className="flex-1 flex flex-col bg-emerald-500 text-white p-6 rounded-3xl text-center justify-center">
                        <UserCheck size={64} className="mx-auto mb-4 text-emerald-200" />
                        <h4 className="text-3xl font-bold mb-1">VALID</h4>
                        {scannedTicket?.digitalSignature && <div className="flex items-center justify-center gap-1 text-xs opacity-80 mb-4 bg-emerald-600/30 py-1 px-3 rounded-full w-fit mx-auto"><ShieldCheck size={12} /> DIGITALLY SIGNED</div>}
                        
                        {/* Conditional Buttons based on status */}
                        {scannedTicket && (
                            <div className="space-y-3 mt-6">
                                {scannedTicket.status === TicketStatus.PENDING ? (
                                    <>
                                        <div className="bg-white/20 p-2 rounded-xl mb-4">
                                            <p className="text-sm font-bold uppercase opacity-80">Payment Pending</p>
                                            <p className="text-2xl font-bold">₹{scannedTicket.totalPrice}</p>
                                        </div>
                                        <Button variant="secondary" fullWidth onClick={() => processBoarding(PaymentMethod.CASH, TicketStatus.BOARDED)} icon={<Wallet size={18} />}>
                                            Collect Cash & Board
                                        </Button>
                                        <button onClick={() => processBoarding(PaymentMethod.ONLINE, TicketStatus.PAID)} className="text-sm font-bold underline opacity-80 mt-2">
                                            Mark Paid Online
                                        </button>
                                    </>
                                ) : (
                                    <>
                                        <div className="bg-emerald-600/30 p-2 rounded-xl mb-4 border border-emerald-400/30">
                                            <p className="text-sm font-bold uppercase flex items-center justify-center gap-2"><Check size={16} /> Paid Online</p>
                                        </div>
                                        <Button variant="secondary" fullWidth onClick={() => processBoarding(scannedTicket.paymentMethod, TicketStatus.BOARDED)}>
                                            Verify & Board Passenger
                                        </Button>
                                    </>
                                )}
                            </div>
                        )}
                        
                        {scannedPass && (
                             <Button variant="secondary" fullWidth onClick={() => { setScannedPass(null); setScannedTicket(null); setTicketIdInput(''); }} className="mt-6">Next Passenger</Button>
                        )}
                    </div>
                )}
            </div>
        </div>
      ))}

      {/* Digital Twin Modal */}
      <Modal 
        isOpen={showDigitalTwin} 
        onClose={() => setShowDigitalTwin(false)} 
        onConfirm={() => setShowDigitalTwin(false)} 
        title="Vehicle Digital Twin" 
        confirmLabel="Close"
      >
          <div className="space-y-4">
              <div className="relative h-48 bg-slate-900 rounded-2xl flex items-center justify-center overflow-hidden border border-slate-700">
                  <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-20"></div>
                  {/* Wireframe Simulation */}
                  <Car size={96} className="text-blue-500/50 animate-pulse relative z-10" />
                  <div className="absolute inset-0 grid grid-cols-4 grid-rows-4">
                      <div className="border border-blue-500/10"></div>
                      <div className="border border-blue-500/10"></div>
                      <div className="border border-blue-500/10"></div>
                      <div className="border border-blue-500/10"></div>
                  </div>
                  <div className="absolute bottom-2 left-2 text-[10px] text-blue-400 font-mono">LIVE TELEMETRY ACTIVE</div>
              </div>

              <div className="space-y-3">
                  {vehicleComponents.map(comp => (
                      <div key={comp.id} className="flex justify-between items-center p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-100 dark:border-slate-700">
                          <div>
                              <p className="font-bold text-sm dark:text-white">{comp.name}</p>
                              {comp.predictedFailureKm && (
                                  <p className="text-[10px] text-red-500 font-bold">Risk in {comp.predictedFailureKm}km</p>
                              )}
                          </div>
                          <div className="text-right">
                              <div className={`text-lg font-bold ${comp.healthPercent > 80 ? 'text-emerald-500' : (comp.healthPercent > 40 ? 'text-amber-500' : 'text-red-500')}`}>
                                  {comp.healthPercent}%
                              </div>
                              <div className="text-[9px] uppercase font-bold text-slate-400">Health</div>
                          </div>
                      </div>
                  ))}
              </div>
          </div>
      </Modal>
    </div>
  );
};
