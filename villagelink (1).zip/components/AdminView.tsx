
import React, { useEffect, useState } from 'react';
import { User, AdminStats } from '../types';
import { getAdminStats, getAllUsers, verifyDriver, toggleUserBan } from '../services/adminService';
import { LayoutDashboard, Users, UserCheck, ShieldAlert, CheckCircle, XCircle, Search, LogOut, Lock, Unlock, Activity, DollarSign } from 'lucide-react';
import { logoutUser } from '../services/authService';

interface AdminViewProps {
    user: User;
}

export const AdminView: React.FC<AdminViewProps> = ({ user }) => {
    const [stats, setStats] = useState<AdminStats | null>(null);
    const [users, setUsers] = useState<User[]>([]);
    const [activeTab, setActiveTab] = useState<'DASHBOARD' | 'DRIVERS' | 'USERS'>('DASHBOARD');
    const [search, setSearch] = useState('');

    const fetchData = async () => {
        const s = await getAdminStats();
        const u = await getAllUsers();
        setStats(s);
        setUsers(u);
    };

    useEffect(() => {
        fetchData();
        const interval = setInterval(fetchData, 10000);
        return () => clearInterval(interval);
    }, []);

    const handleVerify = async (id: string, status: boolean) => {
        await verifyDriver(id, status);
        fetchData();
    };

    const handleBan = async (id: string, status: boolean) => {
        if (confirm(`Are you sure you want to ${status ? 'BAN' : 'UNBAN'} this user?`)) {
            await toggleUserBan(id, status);
            fetchData();
        }
    };

    const pendingDrivers = users.filter(u => u.role === 'DRIVER' && !u.isVerified);
    const filteredUsers = users.filter(u => 
        u.name.toLowerCase().includes(search.toLowerCase()) || 
        u.id.toLowerCase().includes(search.toLowerCase())
    );

    return (
        <div className="min-h-screen bg-slate-900 text-slate-100 font-sans">
            {/* Header */}
            <div className="bg-slate-950 border-b border-slate-800 p-4 sticky top-0 z-50 flex justify-between items-center">
                <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-red-600 rounded-lg flex items-center justify-center shadow-lg shadow-red-900/50">
                        <ShieldAlert size={20} className="text-white" />
                    </div>
                    <div>
                        <h1 className="text-xl font-bold tracking-tight">Master Panel</h1>
                        <p className="text-[10px] text-slate-400 font-mono">ADMIN: {user.name} ({user.id})</p>
                    </div>
                </div>
                <button onClick={() => { logoutUser(); window.location.reload(); }} className="bg-slate-800 hover:bg-slate-700 p-2 rounded-full transition-colors text-red-400">
                    <LogOut size={20} />
                </button>
            </div>

            <div className="flex flex-col md:flex-row h-[calc(100vh-80px)]">
                {/* Sidebar */}
                <div className="w-full md:w-64 bg-slate-900 border-b md:border-r border-slate-800 p-4 flex flex-row md:flex-col gap-2 overflow-x-auto">
                    <button onClick={() => setActiveTab('DASHBOARD')} className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${activeTab === 'DASHBOARD' ? 'bg-red-600 text-white shadow-lg' : 'hover:bg-slate-800 text-slate-400'}`}>
                        <LayoutDashboard size={18} /> <span className="font-bold text-sm">Dashboard</span>
                    </button>
                    <button onClick={() => setActiveTab('DRIVERS')} className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${activeTab === 'DRIVERS' ? 'bg-red-600 text-white shadow-lg' : 'hover:bg-slate-800 text-slate-400'}`}>
                        <UserCheck size={18} /> <span className="font-bold text-sm">Approvals</span>
                        {pendingDrivers.length > 0 && <span className="bg-white text-red-600 px-1.5 py-0.5 rounded-full text-[10px] font-bold ml-auto">{pendingDrivers.length}</span>}
                    </button>
                    <button onClick={() => setActiveTab('USERS')} className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${activeTab === 'USERS' ? 'bg-red-600 text-white shadow-lg' : 'hover:bg-slate-800 text-slate-400'}`}>
                        <Users size={18} /> <span className="font-bold text-sm">User Mgmt</span>
                    </button>
                </div>

                {/* Content */}
                <div className="flex-1 p-6 overflow-y-auto bg-slate-950/50">
                    {activeTab === 'DASHBOARD' && stats && (
                        <div className="space-y-6 animate-in fade-in">
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800">
                                    <p className="text-slate-500 text-xs font-bold uppercase">Total Users</p>
                                    <p className="text-3xl font-bold mt-1 text-white">{stats.totalUsers}</p>
                                </div>
                                <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800">
                                    <p className="text-slate-500 text-xs font-bold uppercase">Pending Drivers</p>
                                    <p className="text-3xl font-bold mt-1 text-orange-500">{stats.pendingDrivers}</p>
                                </div>
                                <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800">
                                    <p className="text-slate-500 text-xs font-bold uppercase">Active Trips</p>
                                    <p className="text-3xl font-bold mt-1 text-emerald-500">{stats.activeTrips}</p>
                                </div>
                                <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800">
                                    <p className="text-slate-500 text-xs font-bold uppercase">System Health</p>
                                    <p className="text-3xl font-bold mt-1 text-blue-500 flex items-center gap-2">{stats.systemHealth}% <Activity size={18} /></p>
                                </div>
                            </div>

                            <div className="bg-slate-900 rounded-3xl p-6 border border-slate-800">
                                <h3 className="text-lg font-bold mb-4 flex items-center gap-2"><DollarSign size={20} className="text-yellow-500" /> Platform Financials</h3>
                                <div className="grid grid-cols-2 gap-8">
                                    <div>
                                        <p className="text-sm text-slate-400">Total Volume</p>
                                        <p className="text-4xl font-mono text-white">₹{stats.totalRevenue.toLocaleString()}</p>
                                    </div>
                                    <div className="border-l border-slate-800 pl-8">
                                        <p className="text-sm text-slate-400">Escrow Held</p>
                                        <p className="text-4xl font-mono text-emerald-400">₹{(stats.totalRevenue * 0.15).toLocaleString()}</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}

                    {activeTab === 'DRIVERS' && (
                        <div className="space-y-4 animate-in slide-in-from-right-4">
                            <h2 className="text-xl font-bold mb-4">Pending Verifications</h2>
                            {pendingDrivers.length === 0 ? (
                                <div className="text-center py-20 text-slate-500 bg-slate-900/50 rounded-3xl border border-slate-800">
                                    <UserCheck size={48} className="mx-auto mb-4 opacity-20" />
                                    <p>No drivers pending approval</p>
                                </div>
                            ) : (
                                pendingDrivers.map(d => (
                                    <div key={d.id} className="bg-slate-900 p-6 rounded-2xl border border-slate-800 flex flex-col md:flex-row justify-between items-center gap-4">
                                        <div className="flex items-center gap-4 w-full md:w-auto">
                                            <div className="w-12 h-12 bg-slate-800 rounded-full flex items-center justify-center text-lg font-bold">
                                                {d.name.charAt(0)}
                                            </div>
                                            <div>
                                                <h3 className="font-bold text-lg">{d.name}</h3>
                                                <p className="text-sm text-slate-400 font-mono">{d.id}</p>
                                                <div className="flex gap-2 mt-1">
                                                    <span className="text-[10px] bg-slate-800 px-2 py-0.5 rounded text-slate-300">{d.phone || d.email}</span>
                                                    <span className="text-[10px] bg-slate-800 px-2 py-0.5 rounded text-slate-300">Cap: {d.vehicleCapacity}</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="flex gap-3 w-full md:w-auto">
                                            <button onClick={() => handleVerify(d.id, false)} className="flex-1 md:flex-none bg-slate-800 hover:bg-slate-700 text-slate-300 px-4 py-2 rounded-lg font-bold text-sm">Reject</button>
                                            <button onClick={() => handleVerify(d.id, true)} className="flex-1 md:flex-none bg-emerald-600 hover:bg-emerald-500 text-white px-6 py-2 rounded-lg font-bold text-sm flex items-center justify-center gap-2">
                                                <CheckCircle size={16} /> Approve
                                            </button>
                                        </div>
                                    </div>
                                ))
                            )}
                        </div>
                    )}

                    {activeTab === 'USERS' && (
                        <div className="space-y-4 animate-in slide-in-from-right-4">
                            <div className="relative mb-6">
                                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
                                <input 
                                    value={search} 
                                    onChange={(e) => setSearch(e.target.value)} 
                                    className="w-full bg-slate-900 border border-slate-800 rounded-xl py-3 pl-12 pr-4 text-slate-200 outline-none focus:border-red-600"
                                    placeholder="Search users by name or ID..."
                                />
                            </div>
                            <div className="space-y-2">
                                {filteredUsers.map(u => (
                                    <div key={u.id} className={`p-4 rounded-xl border flex justify-between items-center ${u.isBanned ? 'bg-red-900/10 border-red-900/50' : 'bg-slate-900 border-slate-800'}`}>
                                        <div>
                                            <div className="flex items-center gap-2">
                                                <span className="font-bold">{u.name}</span>
                                                <span className={`text-[10px] px-2 rounded font-bold ${u.role === 'ADMIN' ? 'bg-red-600 text-white' : (u.role === 'DRIVER' ? 'bg-indigo-600 text-white' : 'bg-slate-700 text-slate-300')}`}>{u.role}</span>
                                                {u.isBanned && <span className="text-[10px] bg-red-600 text-white px-2 rounded font-bold">BANNED</span>}
                                            </div>
                                            <p className="text-xs text-slate-500 font-mono">{u.id}</p>
                                        </div>
                                        {u.role !== 'ADMIN' && (
                                            <button 
                                                onClick={() => handleBan(u.id, !u.isBanned)}
                                                className={`p-2 rounded-lg transition-colors ${u.isBanned ? 'bg-emerald-600/20 text-emerald-500 hover:bg-emerald-600/30' : 'bg-red-600/20 text-red-500 hover:bg-red-600/30'}`}
                                            >
                                                {u.isBanned ? <Unlock size={18} /> : <Lock size={18} />}
                                            </button>
                                        )}
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};
