import React, { useEffect, useState } from 'react';
import { User, Wallet } from '../types';
import { getAuthToken } from '../services/authService';
import { getWallet } from '../services/blockchainService';
import { ArrowLeft, History, MapPin, Calendar, CreditCard, Wallet as WalletIcon, User as UserIcon, Mail, Phone, Shield, Bus, Package, Car, Ticket as TicketIcon, Gem, Layers, Filter, CheckCircle2, Clock } from 'lucide-react';

interface UserProfileProps {
  user: User;
  onBack: () => void;
}

type FilterType = 'ALL' | 'TRIPS' | 'PASSES' | 'PARCELS';

export const UserProfile: React.FC<UserProfileProps> = ({ user, onBack }) => {
  const [history, setHistory] = useState<any[]>([]);
  const [wallet, setWallet] = useState<Wallet | null>(null);
  const [activeTab, setActiveTab] = useState<'HISTORY' | 'WALLET'>('HISTORY');
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<FilterType>('ALL');

  useEffect(() => {
    const fetchHistory = async () => {
      const token = getAuthToken();
      try {
        const res = await fetch(`/api/user/history?userId=${user.id}`, {
          headers: { 'Authorization': token || '' }
        });
        const data = await res.json();
        if (Array.isArray(data)) setHistory(data);
      } catch (e) {
        console.error("Failed to load history", e);
      } finally {
        setLoading(false);
      }
    };
    
    const fetchWallet = async () => {
        const w = await getWallet(user.id);
        setWallet(w);
    };

    fetchWallet();
    fetchHistory();
  }, [user.id]);

  const getFilteredHistory = () => {
    return history.filter(item => {
      if (filter === 'ALL') return true;
      if (filter === 'TRIPS') return item.historyType === 'TICKET' || item.historyType === 'RENTAL';
      if (filter === 'PASSES') return item.historyType === 'PASS';
      if (filter === 'PARCELS') return item.historyType === 'PARCEL';
      return true;
    });
  };

  const groupHistoryByDate = (items: any[]) => {
    const groups: Record<string, any[]> = {};
    items.forEach(item => {
      // Use window.Date to avoid shadowing issues if Date is declared locally
      const dateVal = item.timestamp || item.purchaseDate || (item.date ? new window.Date(item.date).getTime() : window.Date.now());
      const dateObj = new window.Date(dateVal);
      
      // Smart Date Label
      const today = new window.Date();
      const yesterday = new window.Date();
      yesterday.setDate(today.getDate() - 1);
      
      let dateStr = dateObj.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
      
      if (dateObj.toDateString() === today.toDateString()) dateStr = 'Today';
      else if (dateObj.toDateString() === yesterday.toDateString()) dateStr = 'Yesterday';

      if (!groups[dateStr]) groups[dateStr] = [];
      groups[dateStr].push(item);
    });
    return groups;
  };

  const renderHistoryItem = (item: any) => {
    switch(item.historyType) {
        case 'PASS':
            return (
                <div key={item.id} className="bg-gradient-to-br from-purple-50 to-white dark:from-purple-900/20 dark:to-slate-900 rounded-2xl p-4 shadow-sm border border-purple-100 dark:border-purple-800/50 relative overflow-hidden group">
                    <div className="flex justify-between items-start mb-2">
                        <div className="flex items-center gap-2">
                            <span className="bg-purple-100 text-purple-600 dark:bg-purple-900 dark:text-purple-300 p-1.5 rounded-lg"><CreditCard size={14} /></span>
                            <span className="font-bold text-sm text-slate-700 dark:text-slate-200">Monthly Pass</span>
                        </div>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${item.status === 'ACTIVE' ? 'bg-emerald-100 text-emerald-600' : 'bg-slate-100 text-slate-500'}`}>{item.status}</span>
                    </div>
                    <div className="pl-9">
                         <p className="text-base font-bold dark:text-white flex items-center gap-2">
                            {item.from} <ArrowLeft size={12} className="rotate-180 text-slate-400" /> {item.to}
                         </p>
                         <p className="text-[10px] text-slate-500 mt-1">Valid until {new window.Date(item.expiryDate).toLocaleDateString()}</p>
                    </div>
                </div>
            );
        case 'RENTAL':
            return (
                <div key={item.id} className="bg-white dark:bg-slate-900 rounded-2xl p-4 shadow-sm border border-slate-100 dark:border-slate-800">
                     <div className="flex justify-between items-start mb-2">
                        <div className="flex items-center gap-2">
                            <span className="bg-indigo-100 text-indigo-600 dark:bg-indigo-900 dark:text-indigo-300 p-1.5 rounded-lg"><Car size={14} /></span>
                            <span className="font-bold text-sm text-slate-700 dark:text-slate-200">Charter</span>
                        </div>
                        <span className="font-mono text-[10px] text-slate-400 bg-slate-50 dark:bg-slate-800 px-2 py-0.5 rounded">{item.vehicleType}</span>
                     </div>
                     <div className="pl-9">
                        <p className="text-sm font-bold dark:text-white">{item.from} → {item.to}</p>
                        <div className="flex justify-between items-center mt-2">
                            <span className="text-xs font-bold text-slate-500">₹{item.totalFare}</span>
                            <span className="text-[10px] flex items-center gap-1 text-emerald-500"><Shield size={10} /> Escrow Secured</span>
                        </div>
                     </div>
                </div>
            );
        case 'PARCEL':
            return (
                <div key={item.id} className="bg-white dark:bg-slate-900 rounded-2xl p-4 shadow-sm border border-slate-100 dark:border-slate-800">
                    <div className="flex justify-between items-start mb-2">
                        <div className="flex items-center gap-2">
                            <span className="bg-orange-100 text-orange-600 dark:bg-orange-900 dark:text-orange-300 p-1.5 rounded-lg"><Package size={14} /></span>
                            <span className="font-bold text-sm text-slate-700 dark:text-slate-200">Parcel</span>
                        </div>
                        <span className="text-[10px] font-bold text-slate-400">{item.weightKg} KG</span>
                    </div>
                    <div className="pl-9">
                        <p className="text-sm font-bold dark:text-white">{item.from} → {item.to}</p>
                        <div className="mt-2 text-[10px] text-slate-400 font-mono break-all truncate">
                            Hash: {item.blockchainHash?.substring(0, 16)}...
                        </div>
                    </div>
                </div>
            );
        default: // TICKET
            return (
                <div key={item.id} className="bg-white dark:bg-slate-900 rounded-2xl p-4 shadow-sm border border-slate-100 dark:border-slate-800">
                    <div className="flex justify-between items-start mb-2">
                        <div className="flex items-center gap-2">
                            <span className="bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300 p-1.5 rounded-lg"><Bus size={14} /></span>
                            <span className="font-bold text-sm text-slate-700 dark:text-slate-200">Bus Trip</span>
                        </div>
                        <span className="text-[10px] font-bold text-slate-400">₹{item.totalPrice}</span>
                    </div>
                    <div className="pl-9">
                        <p className="text-sm font-bold dark:text-white flex items-center gap-2">
                            {item.from} <ArrowLeft size={12} className="rotate-180 text-slate-300" /> {item.to}
                        </p>
                        <p className="text-[10px] text-slate-400 mt-1">{item.passengerCount} Passenger{item.passengerCount > 1 ? 's' : ''}</p>
                    </div>
                </div>
            );
    }
  }

  const groupedHistory = groupHistoryByDate(getFilteredHistory());

  return (
    <div className="animate-fade-in pb-20 min-h-screen bg-slate-50 dark:bg-black">
      <div className="flex items-center gap-4 mb-6 sticky top-0 bg-slate-50/90 dark:bg-black/90 backdrop-blur-md p-4 z-20 border-b border-slate-200/50 dark:border-slate-800">
        <button onClick={onBack} className="p-2 rounded-full bg-white/80 dark:bg-slate-800/80 hover:bg-white dark:hover:bg-slate-700 transition-colors shadow-sm">
          <ArrowLeft size={20} className="dark:text-white" />
        </button>
        <h2 className="text-xl font-bold dark:text-white">Profile & Activity</h2>
      </div>

      {/* User Card */}
      <div className="px-4 mb-6">
        <div className="bg-white dark:bg-slate-900 p-6 rounded-[32px] shadow-sm border border-slate-100 dark:border-slate-800 flex items-center gap-4">
            <div className="w-16 h-16 bg-gradient-to-br from-brand-500 to-indigo-600 rounded-2xl flex items-center justify-center text-2xl font-bold text-white shadow-lg shadow-brand-500/20">
                {user.name.charAt(0)}
            </div>
            <div>
                <h3 className="text-lg font-bold dark:text-white">{user.name}</h3>
                <div className="flex items-center gap-2 text-xs text-slate-500">
                    <span className="bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded font-medium">{user.role}</span>
                    <span>•</span>
                    <span className="font-mono">{user.id}</span>
                </div>
            </div>
        </div>
      </div>

      {/* Tab Switcher */}
      <div className="px-4 mb-6">
        <div className="flex p-1 bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800">
            <button onClick={() => setActiveTab('HISTORY')} className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${activeTab === 'HISTORY' ? 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white' : 'text-slate-400'}`}>
                <History size={14} /> Activity
            </button>
            <button onClick={() => setActiveTab('WALLET')} className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${activeTab === 'WALLET' ? 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white' : 'text-slate-400'}`}>
                <WalletIcon size={14} /> Wallet
            </button>
        </div>
      </div>

      {activeTab === 'WALLET' && wallet && (
          <div className="animate-fade-in space-y-6 px-4">
              <div className="bg-gradient-to-br from-yellow-400 to-orange-500 rounded-[32px] p-6 text-white shadow-lg relative overflow-hidden">
                  <div className="absolute -right-10 -top-10 w-40 h-40 bg-white/20 rounded-full blur-3xl"></div>
                  <p className="text-xs font-bold uppercase opacity-80 mb-1 flex items-center gap-1"><Gem size={12} /> GramCoin Balance</p>
                  <h3 className="text-4xl font-bold mb-4">{wallet.balance}</h3>
                  <div className="flex items-center justify-between text-[10px] opacity-80">
                      <span className="font-mono bg-black/10 px-2 py-1 rounded">{wallet.address.substring(0, 12)}...</span>
                      <span>Verified on TrustChain</span>
                  </div>
              </div>

              <div>
                  <h4 className="font-bold text-sm text-slate-500 uppercase mb-4 pl-1">Recent Transactions</h4>
                  <div className="space-y-3">
                      {wallet.transactions.map(tx => (
                          <div key={tx.id} className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-100 dark:border-slate-800 flex justify-between items-center">
                              <div className="flex items-center gap-3">
                                  <div className={`p-2 rounded-full ${tx.type === 'EARN' ? 'bg-emerald-100 text-emerald-600' : 'bg-red-100 text-red-600'}`}>
                                      {tx.type === 'EARN' ? <ArrowLeft size={16} className="rotate-45" /> : <ArrowLeft size={16} className="-rotate-[135deg]" />}
                                  </div>
                                  <div>
                                      <p className="font-bold text-sm dark:text-white">{tx.desc}</p>
                                      <p className="text-[10px] text-slate-400">{new window.Date(tx.timestamp).toLocaleDateString()}</p>
                                  </div>
                              </div>
                              <span className={`font-bold text-sm ${tx.type === 'EARN' ? 'text-emerald-500' : 'text-slate-500'}`}>
                                  {tx.type === 'EARN' ? '+' : '-'}{tx.amount}
                              </span>
                          </div>
                      ))}
                  </div>
              </div>
          </div>
      )}

      {activeTab === 'HISTORY' && (
        <div className="animate-fade-in px-4">
            {/* Filter Pills */}
            <div className="flex gap-2 overflow-x-auto pb-4 scrollbar-hide mb-2">
                {[
                    { id: 'ALL', label: 'All Activity', icon: Layers },
                    { id: 'TRIPS', label: 'Trips', icon: Bus },
                    { id: 'PASSES', label: 'Passes', icon: TicketIcon },
                    { id: 'PARCELS', label: 'Parcels', icon: Package }
                ].map((f) => (
                    <button
                        key={f.id}
                        onClick={() => setFilter(f.id as FilterType)}
                        className={`flex items-center gap-2 px-4 py-2 rounded-full text-xs font-bold whitespace-nowrap transition-all border ${filter === f.id ? 'bg-brand-600 text-white border-brand-600' : 'bg-white dark:bg-slate-900 text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-800'}`}
                    >
                        <f.icon size={12} /> {f.label}
                    </button>
                ))}
            </div>

            {loading ? (
                <div className="text-center py-20 text-slate-400 flex flex-col items-center gap-2">
                    <div className="w-6 h-6 border-2 border-brand-500 border-t-transparent rounded-full animate-spin"></div>
                    <p className="text-xs">Loading history...</p>
                </div>
            ) : Object.keys(groupedHistory).length === 0 ? (
                <div className="text-center py-20 text-slate-400">
                    <History size={32} className="mx-auto mb-3 opacity-20" />
                    <p className="text-sm">No history found</p>
                </div>
            ) : (
                <div className="relative border-l-2 border-slate-200 dark:border-slate-800 ml-4 space-y-8">
                    {Object.entries(groupedHistory).map(([dateLabel, items]) => (
                        <div key={dateLabel} className="relative pl-6">
                            {/* Timeline Dot & Date */}
                            <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-slate-200 dark:bg-slate-800 border-4 border-white dark:border-black flex items-center justify-center">
                                <div className="w-1.5 h-1.5 bg-slate-400 rounded-full"></div>
                            </div>
                            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4 mt-0.5">{dateLabel}</h4>
                            
                            <div className="space-y-3">
                                {items.map((item, idx) => (
                                    <div key={idx}>{renderHistoryItem(item)}</div>
                                ))}
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
      )}
    </div>
  );
};